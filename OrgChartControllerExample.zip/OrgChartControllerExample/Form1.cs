﻿using DevExpress.Diagram.Core;
using DevExpress.XtraDiagram;
using DevExpress.XtraDiagram.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OrgChartControllerExample
{
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        private bool mousePressed = false;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void ribbonGalleryBarItem1_GalleryItemClick(object sender, DevExpress.XtraBars.Ribbon.GalleryItemClickEventArgs e)
        {
            diagramControl1.Commands.Execute(DiagramCommands.StartDragToolCommand, new ShapeTool(BasicShapes.Rectangle));
        }

        private void diagramControl1_CustomItemQueryContinueDrag(object sender, DiagramCustomItemQueryContinueDragEventArgs e)
        {
            if (e.IsCancellationRequested)
            {
                e.Action = DragAction.Cancel;
                return;
            }
            if (e.KeyStates.HasFlag(DragDropKeyState.LeftMouseButton))
                mousePressed = true;
            else if (mousePressed)
            {
                e.Action = DragAction.Drop;
                return;
            }
            e.Action = DragAction.Continue;
        }

        private void diagramControl1_CustomItemDragResult(object sender, DiagramCustomItemDragResultEventArgs e)
        {
            mousePressed = false;
        }


        private void bbiState_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e) {
            diagramControl1.Commands.Execute(DiagramCommands.StartDragToolCommand, new ShapeTool(BasicShapes.Rectangle));

        }
    }
}
