﻿namespace OrgChartControllerExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem5 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem6 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem7 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip8 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem8 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip9 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem9 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip10 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem10 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip11 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem11 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip12 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem12 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip13 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem13 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip14 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem14 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip15 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem15 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.Skins.SkinPaddingEdges skinPaddingEdges1 = new DevExpress.Skins.SkinPaddingEdges();
            DevExpress.Utils.SuperToolTip superToolTip16 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem16 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip17 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem17 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip18 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem18 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip19 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem19 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip20 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem20 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip21 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem21 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip22 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem22 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip23 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem23 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip24 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem24 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip25 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem25 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip26 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem26 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip27 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem27 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip28 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem28 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip29 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem29 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip30 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem30 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip31 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem31 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip32 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem32 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip33 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem33 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip34 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem34 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup2 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.Utils.SuperToolTip superToolTip35 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem35 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip36 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem36 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip37 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem37 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip38 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem38 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip39 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem39 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip40 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem40 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip41 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem41 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip42 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem42 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip43 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem43 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip44 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem44 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip45 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem45 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip46 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem46 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip47 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem47 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip48 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem48 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip49 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem49 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip50 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem50 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip51 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem51 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip52 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem52 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip53 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem53 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip54 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem54 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip55 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem55 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip56 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem56 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip57 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem57 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.SuperToolTip superToolTip58 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem58 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup3 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.Utils.SuperToolTip superToolTip59 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem59 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup4 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup5 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup6 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraBars.Ribbon.GalleryItem galleryItem1 = new DevExpress.XtraBars.Ribbon.GalleryItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.diagramControl1 = new DevExpress.XtraDiagram.DiagramControl();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.applicationMenu1 = new DevExpress.XtraBars.Ribbon.ApplicationMenu(this.components);
            this.diagramCommandNewFileBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandNewFileBarButtonItem();
            this.diagramCommandOpenFileBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandOpenFileBarButtonItem();
            this.diagramCommandSaveFileBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileBarButtonItem();
            this.diagramCommandSaveFileAsBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileAsBarButtonItem();
            this.diagramCommandShowPrintPreviewBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShowPrintPreviewBarButtonItem();
            this.diagramCommandPrintMenuBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPrintMenuBarSplitButtonItem();
            this.PrintMenuPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.diagramCommandPrintBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPrintBarButtonItem();
            this.diagramCommandQuickPrintBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandQuickPrintBarButtonItem();
            this.diagramCommandExportAsBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandExportAsBarSplitButtonItem();
            this.ExportAsPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.diagramCommandExportDiagram_PNGBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_PNGBarButtonItem();
            this.diagramCommandExportDiagram_JPEGBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_JPEGBarButtonItem();
            this.diagramCommandExportDiagram_BMPBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_BMPBarButtonItem();
            this.diagramCommandExportDiagram_GIFBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_GIFBarButtonItem();
            this.barAndDockingController1 = new DevExpress.XtraBars.BarAndDockingController(this.components);
            this.diagramCommandUndoBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandUndoBarButtonItem();
            this.diagramCommandRedoBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandRedoBarButtonItem();
            this.diagramStatusBarShapeInfoBarStaticItem1 = new DevExpress.XtraDiagram.Bars.DiagramStatusBarShapeInfoBarStaticItem();
            this.diagramCommandStatusBarZoomEditorBarEditItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem();
            this.diagramRepositoryItemZoomTrackBar1 = new DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem.DiagramRepositoryItemZoomTrackBar();
            this.diagramCommandContainerPaddingBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPaddingBarDropDownItem();
            this.diagramCommandContainerPadding_P0BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P0BarCheckItem();
            this.diagramCommandContainerPadding_P4BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P4BarCheckItem();
            this.diagramCommandContainerPadding_P8BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P8BarCheckItem();
            this.diagramCommandContainerPadding_P12BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P12BarCheckItem();
            this.diagramCommandContainerPadding_P16BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P16BarCheckItem();
            this.diagramCommandContainerPadding_P24BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P24BarCheckItem();
            this.diagramCommandContainerPadding_P32BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P32BarCheckItem();
            this.diagramCommandContainerHeaderPaddingBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPaddingBarDropDownItem();
            this.diagramCommandContainerHeaderPadding_P0BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P0BarCheckItem();
            this.diagramCommandContainerHeaderPadding_P4BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P4BarCheckItem();
            this.diagramCommandContainerHeaderPadding_P8BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P8BarCheckItem();
            this.diagramCommandContainerHeaderPadding_P12BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P12BarCheckItem();
            this.diagramCommandContainerHeaderPadding_P16BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P16BarCheckItem();
            this.diagramCommandContainerHeaderPadding_P24BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P24BarCheckItem();
            this.diagramCommandContainerHeaderPadding_P32BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P32BarCheckItem();
            this.diagramCommandContainerStylesBarGalleryItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandContainerStylesBarGalleryItem();
            this.diagramCommandShowContainerHeaderBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShowContainerHeaderBarCheckItem();
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsBringToFrontContainerBarSplitButtonItem();
            this.ImageToolsBringToFrontContainerPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.diagramCommandBringForwardBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandBringForwardBarButtonItem();
            this.diagramCommandBringToFrontBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarButtonItem();
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSendToBackContainerBarSplitButtonItem();
            this.ImageToolsSendToBackContainerPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.diagramCommandSendBackwardBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSendBackwardBarButtonItem();
            this.diagramCommandSendToBackBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarButtonItem();
            this.diagramCommandImageToolsRotateBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsRotateBarDropDownItem();
            this.diagramCommandRotate_Right90BarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Right90BarButtonItem();
            this.diagramCommandRotate_Left90BarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Left90BarButtonItem();
            this.diagramCommandFlipImage_VerticalBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_VerticalBarButtonItem();
            this.diagramCommandFlipImage_HorizontalBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_HorizontalBarButtonItem();
            this.diagramCommandImageToolsStretchModeBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsStretchModeBarDropDownItem();
            this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem();
            this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem();
            this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem();
            this.diagramCommandImageToolsSetImageScaleBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScaleBarDropDownItem();
            this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_25BarCheckItem();
            this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_5BarCheckItem();
            this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_75BarCheckItem();
            this.diagramCommandImageToolsSetImageScale_1BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1BarCheckItem();
            this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1_5BarCheckItem();
            this.diagramCommandImageToolsSetImageScale_2BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_2BarCheckItem();
            this.diagramCommandImageToolsSetImageScale_4BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_4BarCheckItem();
            this.diagramCommandResetSelectedImagesBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandResetSelectedImagesBarButtonItem();
            this.diagramCommandLoadImageBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandLoadImageBarButtonItem();
            this.diagramCommandShowRulersBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShowRulersBarCheckItem();
            this.diagramCommandShowGridBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShowGridBarCheckItem();
            this.diagramCommandShowPageBreaksBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShowPageBreaksBarCheckItem();
            this.diagramCommandPanesBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPanesBarDropDownItem();
            this.diagramCommandShapesPanelBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShapesPanelBarCheckItem();
            this.diagramCommandPropertiesPanelBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPropertiesPanelBarCheckItem();
            this.diagramCommandFitToPageBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFitToPageBarButtonItem();
            this.diagramCommandFitToWidthBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFitToWidthBarButtonItem();
            this.diagramCommandPageOrientationBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientationBarDropDownItem();
            this.diagramCommandPageOrientation_HorizontalBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_HorizontalBarCheckItem();
            this.diagramCommandPageOrientation_VerticalBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_VerticalBarCheckItem();
            this.diagramCommandPageSizeBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSizeBarDropDownItem();
            this.diagramCommandPageSize_LetterBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LetterBarCheckItem();
            this.diagramCommandPageSize_TabloidBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_TabloidBarCheckItem();
            this.diagramCommandPageSize_LegalBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LegalBarCheckItem();
            this.diagramCommandPageSize_StatementBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_StatementBarCheckItem();
            this.diagramCommandPageSize_ExecutiveBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_ExecutiveBarCheckItem();
            this.diagramCommandPageSize_A3BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A3BarCheckItem();
            this.diagramCommandPageSize_A4BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A4BarCheckItem();
            this.diagramCommandPageSize_A5BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A5BarCheckItem();
            this.diagramCommandPageSize_B4BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B4BarCheckItem();
            this.diagramCommandPageSize_B5BarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B5BarCheckItem();
            this.diagramCommandFitToDrawingBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFitToDrawingBarButtonItem();
            this.diagramCommandSetPageParameters_PageSizeBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetPageParameters_PageSizeBarButtonItem();
            this.diagramCommandAutoSizeBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandAutoSizeBarDropDownItem();
            this.diagramCommandAutoSize_NoneBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_NoneBarCheckItem();
            this.diagramCommandAutoSize_AutoSizeBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_AutoSizeBarCheckItem();
            this.diagramCommandAutoSize_FillBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_FillBarCheckItem();
            this.diagramCommandThemesBarGalleryItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandThemesBarGalleryItem();
            this.diagramCommandSnapToItemsBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSnapToItemsBarCheckItem();
            this.diagramCommandSnapToGridBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSnapToGridBarCheckItem();
            this.diagramCommandReLayoutBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandReLayoutBarDropDownItem();
            this.diagramReLayoutTreeBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutTreeBarHeaderItem();
            this.diagramCommandTreeLayout_DownBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_DownBarButtonItem();
            this.diagramCommandTreeLayout_UpBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_UpBarButtonItem();
            this.diagramCommandTreeLayout_RightBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_RightBarButtonItem();
            this.diagramCommandTreeLayout_LeftBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_LeftBarButtonItem();
            this.diagramReLayoutTipOverTreeHeaderBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutTipOverTreeHeaderBarHeaderItem();
            this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_LeftToRightBarButtonItem();
            this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_RightToLeftBarButtonItem();
            this.diagramReLayoutMindMapTreeHeaderBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutMindMapTreeHeaderBarHeaderItem();
            this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayout_HorizontalBarButtonItem();
            this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayout_VerticalBarButtonItem();
            this.diagramReLayoutSugiyamaBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutSugiyamaBarHeaderItem();
            this.diagramCommandSugiyamaLayout_DownBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_DownBarButtonItem();
            this.diagramCommandSugiyamaLayout_UpBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_UpBarButtonItem();
            this.diagramCommandSugiyamaLayout_RightBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_RightBarButtonItem();
            this.diagramCommandSugiyamaLayout_LeftBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_LeftBarButtonItem();
            this.diagramReLayoutCircularHeaderBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutCircularHeaderBarHeaderItem();
            this.diagramCommandCircularLayoutBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandCircularLayoutBarButtonItem();
            this.diagramCommandChangeConnectorTypeBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorTypeBarDropDownItem();
            this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorType_RightAngleBarButtonItem();
            this.diagramCommandChangeConnectorType_CurvedBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorType_CurvedBarButtonItem();
            this.diagramCommandChangeConnectorType_StraightBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorType_StraightBarButtonItem();
            this.diagramCommandReLayoutPartsBarDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandReLayoutPartsBarDropDownItem();
            this.diagramReLayoutPartsTreeHeaderBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutPartsTreeHeaderBarHeaderItem();
            this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem();
            this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem();
            this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem();
            this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem();
            this.diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutPartsTipOverTreeHeaderBarHeaderItem();
            this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem();
            this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem();
            this.diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1 = new DevExpress.XtraDiagram.Bars.DiagramReLayoutPartsMindMapTreeHeaderBarHeaderItem();
            this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem();
            this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem();
            this.diagramCommandInsertContainerBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandInsertContainerBarSplitButtonItem();
            this.InsertContainerPopupMenu = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.diagramCommandInsertImageBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandInsertImageBarButtonItem();
            this.diagramCommandPasteBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandPasteBarButtonItem();
            this.diagramCommandCutBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandCutBarButtonItem();
            this.diagramCommandCopyBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandCopyBarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.diagramCommandFontFamilyBarEditItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFontFamilyBarEditItem();
            this.repositoryItemFontEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemFontEdit();
            this.diagramCommandFontSizeBarEditItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandFontSizeBarEditItem();
            this.repositoryItemDiagramFontSizeEdit1 = new DevExpress.XtraDiagram.Bars.RepositoryItemDiagramFontSizeEdit();
            this.diagramCommandIncreaseFontSizeBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandIncreaseFontSizeBarButtonItem();
            this.diagramCommandDecreaseFontSizeBarButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandDecreaseFontSizeBarButtonItem();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.diagramCommandToggleFontBoldBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontBoldBarCheckItem();
            this.diagramCommandToggleFontItalicBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontItalicBarCheckItem();
            this.diagramCommandToggleFontUnderlineBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontUnderlineBarCheckItem();
            this.diagramCommandToggleFontStrikethroughBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontStrikethroughBarCheckItem();
            this.diagramCommandForegroundColorBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandForegroundColorBarSplitButtonItem();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.diagramCommandSetVerticalAlignment_TopBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_TopBarCheckItem();
            this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_CenterBarCheckItem();
            this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_BottomBarCheckItem();
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_LeftBarCheckItem();
            this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_CenterBarCheckItem();
            this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_RightBarCheckItem();
            this.diagramCommandSelectPointerToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectPointerToolBarCheckItem();
            this.diagramCommandSelectConnectorToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectConnectorToolBarCheckItem();
            this.diagramCommandToolsContainerCheckDropDownItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandToolsContainerCheckDropDownItem();
            this.ToolsContainerPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.diagramCommandSelectRectangleToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectRectangleToolBarCheckItem();
            this.diagramCommandSelectEllipseToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectEllipseToolBarCheckItem();
            this.diagramCommandSelectRightTriangleToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectRightTriangleToolBarCheckItem();
            this.diagramCommandSelectHexagonToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectHexagonToolBarCheckItem();
            this.diagramCommandSelectPanToolBarCheckItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectPanToolBarCheckItem();
            this.diagramCommandShapeStylesBarGalleryItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandShapeStylesBarGalleryItem();
            this.diagramCommandBackgroundColorBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandBackgroundColorBarSplitButtonItem();
            this.diagramCommandStrokeColorBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandStrokeColorBarSplitButtonItem();
            this.diagramCommandBringToFrontBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarSplitButtonItem();
            this.BringToFrontPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.diagramCommandSendToBackBarSplitButtonItem1 = new DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarSplitButtonItem();
            this.SendToBackPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
            this.ribbonGalleryBarItem1 = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.bbiState = new DevExpress.XtraBars.BarButtonItem();
            this.bbiBranch = new DevExpress.XtraBars.BarButtonItem();
            this.bbiFinalState = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCompositeInitialStatePointer = new DevExpress.XtraBars.BarButtonItem();
            this.bbiCompositeState = new DevExpress.XtraBars.BarButtonItem();
            this.bbiEntryPoint = new DevExpress.XtraBars.BarButtonItem();
            this.bbiHistoryState = new DevExpress.XtraBars.BarButtonItem();
            this.diagramContainerToolsRibbonPageCategory1 = new DevExpress.XtraDiagram.Bars.DiagramContainerToolsRibbonPageCategory();
            this.diagramFormatContainerRibbonPage1 = new DevExpress.XtraDiagram.Bars.DiagramFormatContainerRibbonPage();
            this.diagramContainerSizeRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramContainerSizeRibbonPageGroup();
            this.diagramContainerStylesRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramContainerStylesRibbonPageGroup();
            this.diagramImageToolsRibbonPageCategory1 = new DevExpress.XtraDiagram.Bars.DiagramImageToolsRibbonPageCategory();
            this.diagramFormatImageRibbonPage1 = new DevExpress.XtraDiagram.Bars.DiagramFormatImageRibbonPage();
            this.diagramImageTools_ArrangeRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramImageTools_ArrangeRibbonPageGroup();
            this.diagramImageTools_PictureRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramImageTools_PictureRibbonPageGroup();
            this.diagramHomeRibbonPage1 = new DevExpress.XtraDiagram.Bars.DiagramHomeRibbonPage();
            this.diagramClipboardRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramClipboardRibbonPageGroup();
            this.diagramFontRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramFontRibbonPageGroup();
            this.diagramParagraphRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramParagraphRibbonPageGroup();
            this.diagramToolsRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramToolsRibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.diagramShapeStylesRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramShapeStylesRibbonPageGroup();
            this.diagramArrangeRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramArrangeRibbonPageGroup();
            this.diagramInsertRibbonPage1 = new DevExpress.XtraDiagram.Bars.DiagramInsertRibbonPage();
            this.diagramDiagramPartsRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramDiagramPartsRibbonPageGroup();
            this.diagramDesignRibbonPage1 = new DevExpress.XtraDiagram.Bars.DiagramDesignRibbonPage();
            this.diagramPageSetupRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramPageSetupRibbonPageGroup();
            this.diagramThemesRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramThemesRibbonPageGroup();
            this.diagramOptionsRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramOptionsRibbonPageGroup();
            this.diagramTreeLayoutRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramTreeLayoutRibbonPageGroup();
            this.diagramViewRibbonPage1 = new DevExpress.XtraDiagram.Bars.DiagramViewRibbonPage();
            this.diagramShowRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramShowRibbonPageGroup();
            this.diagramZoomRibbonPageGroup1 = new DevExpress.XtraDiagram.Bars.DiagramZoomRibbonPageGroup();
            this.ribbonStatusBar1 = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.diagramBarController1 = new DevExpress.XtraDiagram.Bars.DiagramBarController(this.components);
            this.diagramCommandSelectConnectorToolBarCheckItem2 = new DevExpress.XtraDiagram.Bars.DiagramCommandSelectConnectorToolBarCheckItem();
            ((System.ComponentModel.ISupportInitialize)(this.diagramControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintMenuPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExportAsPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diagramRepositoryItemZoomTrackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageToolsBringToFrontContainerPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageToolsSendToBackContainerPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InsertContainerPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDiagramFontSizeEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToolsContainerPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BringToFrontPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SendToBackPopupMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diagramBarController1)).BeginInit();
            this.SuspendLayout();
            // 
            // diagramControl1
            // 
            this.diagramControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.diagramControl1.Location = new System.Drawing.Point(0, 141);
            this.diagramControl1.Name = "diagramControl1";
            this.diagramControl1.OptionsBehavior.SelectedStencils = new DevExpress.Diagram.Core.StencilCollection(new string[0]);
            this.diagramControl1.OptionsView.PaperKind = System.Drawing.Printing.PaperKind.Letter;
            this.diagramControl1.OptionsView.ShowGrid = false;
            this.diagramControl1.OptionsView.ShowPageBreaks = false;
            this.diagramControl1.OptionsView.ShowRulers = false;
            this.diagramControl1.Size = new System.Drawing.Size(2301, 543);
            this.diagramControl1.TabIndex = 0;
            this.diagramControl1.CustomItemDragResult += new System.EventHandler<DevExpress.XtraDiagram.DiagramCustomItemDragResultEventArgs>(this.diagramControl1_CustomItemDragResult);
            this.diagramControl1.CustomItemQueryContinueDrag += new System.EventHandler<DevExpress.XtraDiagram.DiagramCustomItemQueryContinueDragEventArgs>(this.diagramControl1_CustomItemQueryContinueDrag);
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonDropDownControl = this.applicationMenu1;
            this.ribbonControl1.Controller = this.barAndDockingController1;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.diagramCommandNewFileBarButtonItem1,
            this.diagramCommandOpenFileBarButtonItem1,
            this.diagramCommandSaveFileBarButtonItem1,
            this.diagramCommandSaveFileAsBarButtonItem1,
            this.diagramCommandShowPrintPreviewBarButtonItem1,
            this.diagramCommandPrintMenuBarSplitButtonItem1,
            this.diagramCommandPrintBarButtonItem1,
            this.diagramCommandQuickPrintBarButtonItem1,
            this.diagramCommandExportAsBarSplitButtonItem1,
            this.diagramCommandExportDiagram_PNGBarButtonItem1,
            this.diagramCommandExportDiagram_JPEGBarButtonItem1,
            this.diagramCommandExportDiagram_BMPBarButtonItem1,
            this.diagramCommandExportDiagram_GIFBarButtonItem1,
            this.diagramCommandUndoBarButtonItem1,
            this.diagramCommandRedoBarButtonItem1,
            this.diagramStatusBarShapeInfoBarStaticItem1,
            this.diagramCommandStatusBarZoomEditorBarEditItem1,
            this.diagramCommandContainerPaddingBarDropDownItem1,
            this.diagramCommandContainerHeaderPaddingBarDropDownItem1,
            this.diagramCommandContainerPadding_P0BarCheckItem1,
            this.diagramCommandContainerPadding_P4BarCheckItem1,
            this.diagramCommandContainerPadding_P8BarCheckItem1,
            this.diagramCommandContainerPadding_P12BarCheckItem1,
            this.diagramCommandContainerPadding_P16BarCheckItem1,
            this.diagramCommandContainerPadding_P24BarCheckItem1,
            this.diagramCommandContainerPadding_P32BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P0BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P4BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P8BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P12BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P16BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P24BarCheckItem1,
            this.diagramCommandContainerHeaderPadding_P32BarCheckItem1,
            this.diagramCommandContainerStylesBarGalleryItem1,
            this.diagramCommandShowContainerHeaderBarCheckItem1,
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1,
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1,
            this.diagramCommandBringForwardBarButtonItem1,
            this.diagramCommandBringToFrontBarButtonItem1,
            this.diagramCommandSendBackwardBarButtonItem1,
            this.diagramCommandSendToBackBarButtonItem1,
            this.diagramCommandImageToolsRotateBarDropDownItem1,
            this.diagramCommandImageToolsStretchModeBarDropDownItem1,
            this.diagramCommandImageToolsSetImageScaleBarDropDownItem1,
            this.diagramCommandResetSelectedImagesBarButtonItem1,
            this.diagramCommandLoadImageBarButtonItem1,
            this.diagramCommandRotate_Right90BarButtonItem1,
            this.diagramCommandRotate_Left90BarButtonItem1,
            this.diagramCommandFlipImage_VerticalBarButtonItem1,
            this.diagramCommandFlipImage_HorizontalBarButtonItem1,
            this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1,
            this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1,
            this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_1BarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_2BarCheckItem1,
            this.diagramCommandImageToolsSetImageScale_4BarCheckItem1,
            this.diagramCommandShowRulersBarCheckItem1,
            this.diagramCommandShowGridBarCheckItem1,
            this.diagramCommandShowPageBreaksBarCheckItem1,
            this.diagramCommandPanesBarDropDownItem1,
            this.diagramCommandShapesPanelBarCheckItem1,
            this.diagramCommandPropertiesPanelBarCheckItem1,
            this.diagramCommandFitToPageBarButtonItem1,
            this.diagramCommandFitToWidthBarButtonItem1,
            this.diagramCommandPageOrientationBarDropDownItem1,
            this.diagramCommandPageSizeBarDropDownItem1,
            this.diagramCommandAutoSizeBarDropDownItem1,
            this.diagramCommandPageOrientation_HorizontalBarCheckItem1,
            this.diagramCommandPageOrientation_VerticalBarCheckItem1,
            this.diagramCommandPageSize_LetterBarCheckItem1,
            this.diagramCommandPageSize_TabloidBarCheckItem1,
            this.diagramCommandPageSize_LegalBarCheckItem1,
            this.diagramCommandPageSize_StatementBarCheckItem1,
            this.diagramCommandPageSize_ExecutiveBarCheckItem1,
            this.diagramCommandPageSize_A3BarCheckItem1,
            this.diagramCommandPageSize_A4BarCheckItem1,
            this.diagramCommandPageSize_A5BarCheckItem1,
            this.diagramCommandPageSize_B4BarCheckItem1,
            this.diagramCommandPageSize_B5BarCheckItem1,
            this.diagramCommandFitToDrawingBarButtonItem1,
            this.diagramCommandSetPageParameters_PageSizeBarButtonItem1,
            this.diagramCommandAutoSize_NoneBarCheckItem1,
            this.diagramCommandAutoSize_AutoSizeBarCheckItem1,
            this.diagramCommandAutoSize_FillBarCheckItem1,
            this.diagramCommandThemesBarGalleryItem1,
            this.diagramCommandSnapToItemsBarCheckItem1,
            this.diagramCommandSnapToGridBarCheckItem1,
            this.diagramCommandReLayoutBarDropDownItem1,
            this.diagramCommandChangeConnectorTypeBarDropDownItem1,
            this.diagramCommandReLayoutPartsBarDropDownItem1,
            this.diagramReLayoutTreeBarHeaderItem1,
            this.diagramCommandTreeLayout_DownBarButtonItem1,
            this.diagramCommandTreeLayout_UpBarButtonItem1,
            this.diagramCommandTreeLayout_RightBarButtonItem1,
            this.diagramCommandTreeLayout_LeftBarButtonItem1,
            this.diagramReLayoutTipOverTreeHeaderBarHeaderItem1,
            this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1,
            this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1,
            this.diagramReLayoutMindMapTreeHeaderBarHeaderItem1,
            this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1,
            this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1,
            this.diagramReLayoutSugiyamaBarHeaderItem1,
            this.diagramCommandSugiyamaLayout_DownBarButtonItem1,
            this.diagramCommandSugiyamaLayout_UpBarButtonItem1,
            this.diagramCommandSugiyamaLayout_RightBarButtonItem1,
            this.diagramCommandSugiyamaLayout_LeftBarButtonItem1,
            this.diagramReLayoutCircularHeaderBarHeaderItem1,
            this.diagramCommandCircularLayoutBarButtonItem1,
            this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1,
            this.diagramCommandChangeConnectorType_CurvedBarButtonItem1,
            this.diagramCommandChangeConnectorType_StraightBarButtonItem1,
            this.diagramReLayoutPartsTreeHeaderBarHeaderItem1,
            this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1,
            this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1,
            this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1,
            this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1,
            this.diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1,
            this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1,
            this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1,
            this.diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1,
            this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1,
            this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1,
            this.diagramCommandInsertContainerBarSplitButtonItem1,
            this.diagramCommandInsertImageBarButtonItem1,
            this.diagramCommandPasteBarButtonItem1,
            this.diagramCommandCutBarButtonItem1,
            this.diagramCommandCopyBarButtonItem1,
            this.barButtonGroup1,
            this.diagramCommandFontFamilyBarEditItem1,
            this.diagramCommandFontSizeBarEditItem1,
            this.diagramCommandIncreaseFontSizeBarButtonItem1,
            this.diagramCommandDecreaseFontSizeBarButtonItem1,
            this.barButtonGroup2,
            this.diagramCommandToggleFontBoldBarCheckItem1,
            this.diagramCommandToggleFontItalicBarCheckItem1,
            this.diagramCommandToggleFontUnderlineBarCheckItem1,
            this.diagramCommandToggleFontStrikethroughBarCheckItem1,
            this.diagramCommandForegroundColorBarSplitButtonItem1,
            this.barButtonGroup3,
            this.diagramCommandSetVerticalAlignment_TopBarCheckItem1,
            this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1,
            this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1,
            this.barButtonGroup4,
            this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1,
            this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1,
            this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1,
            this.diagramCommandSelectPointerToolBarCheckItem1,
            this.diagramCommandSelectConnectorToolBarCheckItem1,
            this.diagramCommandToolsContainerCheckDropDownItem1,
            this.diagramCommandSelectPanToolBarCheckItem1,
            this.diagramCommandSelectRectangleToolBarCheckItem1,
            this.diagramCommandSelectEllipseToolBarCheckItem1,
            this.diagramCommandSelectRightTriangleToolBarCheckItem1,
            this.diagramCommandSelectHexagonToolBarCheckItem1,
            this.diagramCommandShapeStylesBarGalleryItem1,
            this.diagramCommandBackgroundColorBarSplitButtonItem1,
            this.diagramCommandStrokeColorBarSplitButtonItem1,
            this.diagramCommandBringToFrontBarSplitButtonItem1,
            this.diagramCommandSendToBackBarSplitButtonItem1,
            this.ribbonGalleryBarItem1,
            this.bbiState,
            this.bbiBranch,
            this.bbiFinalState,
            this.bbiCompositeInitialStatePointer,
            this.bbiCompositeState,
            this.bbiEntryPoint,
            this.bbiHistoryState});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 175;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.diagramContainerToolsRibbonPageCategory1,
            this.diagramImageToolsRibbonPageCategory1});
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.diagramHomeRibbonPage1,
            this.diagramInsertRibbonPage1,
            this.diagramDesignRibbonPage1,
            this.diagramViewRibbonPage1});
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.diagramCommandSaveFileBarButtonItem1);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.diagramCommandUndoBarButtonItem1);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.diagramCommandRedoBarButtonItem1);
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.diagramRepositoryItemZoomTrackBar1,
            this.repositoryItemFontEdit1,
            this.repositoryItemDiagramFontSizeEdit1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013;
            this.ribbonControl1.Size = new System.Drawing.Size(2301, 141);
            this.ribbonControl1.StatusBar = this.ribbonStatusBar1;
            this.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            // 
            // applicationMenu1
            // 
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandNewFileBarButtonItem1);
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandOpenFileBarButtonItem1);
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandSaveFileBarButtonItem1);
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandSaveFileAsBarButtonItem1);
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandShowPrintPreviewBarButtonItem1);
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandPrintMenuBarSplitButtonItem1);
            this.applicationMenu1.ItemLinks.Add(this.diagramCommandExportAsBarSplitButtonItem1);
            this.applicationMenu1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesTextDescription;
            this.applicationMenu1.MinWidth = 350;
            this.applicationMenu1.Name = "applicationMenu1";
            this.applicationMenu1.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandNewFileBarButtonItem1
            // 
            this.diagramCommandNewFileBarButtonItem1.Id = 1;
            this.diagramCommandNewFileBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandNewFileBarButtonItem1.Name = "diagramCommandNewFileBarButtonItem1";
            // 
            // diagramCommandOpenFileBarButtonItem1
            // 
            this.diagramCommandOpenFileBarButtonItem1.Id = 2;
            this.diagramCommandOpenFileBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandOpenFileBarButtonItem1.Name = "diagramCommandOpenFileBarButtonItem1";
            // 
            // diagramCommandSaveFileBarButtonItem1
            // 
            this.diagramCommandSaveFileBarButtonItem1.Id = 3;
            this.diagramCommandSaveFileBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSaveFileBarButtonItem1.Name = "diagramCommandSaveFileBarButtonItem1";
            // 
            // diagramCommandSaveFileAsBarButtonItem1
            // 
            this.diagramCommandSaveFileAsBarButtonItem1.Id = 4;
            this.diagramCommandSaveFileAsBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSaveFileAsBarButtonItem1.Name = "diagramCommandSaveFileAsBarButtonItem1";
            // 
            // diagramCommandShowPrintPreviewBarButtonItem1
            // 
            this.diagramCommandShowPrintPreviewBarButtonItem1.Id = 5;
            this.diagramCommandShowPrintPreviewBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandShowPrintPreviewBarButtonItem1.Name = "diagramCommandShowPrintPreviewBarButtonItem1";
            // 
            // diagramCommandPrintMenuBarSplitButtonItem1
            // 
            this.diagramCommandPrintMenuBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandPrintMenuBarSplitButtonItem1.DropDownControl = this.PrintMenuPopupMenu;
            this.diagramCommandPrintMenuBarSplitButtonItem1.Id = 6;
            this.diagramCommandPrintMenuBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPrintMenuBarSplitButtonItem1.Name = "diagramCommandPrintMenuBarSplitButtonItem1";
            // 
            // PrintMenuPopupMenu
            // 
            this.PrintMenuPopupMenu.ItemLinks.Add(this.diagramCommandPrintBarButtonItem1);
            this.PrintMenuPopupMenu.ItemLinks.Add(this.diagramCommandQuickPrintBarButtonItem1);
            this.PrintMenuPopupMenu.Name = "PrintMenuPopupMenu";
            this.PrintMenuPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandPrintBarButtonItem1
            // 
            this.diagramCommandPrintBarButtonItem1.Id = 7;
            this.diagramCommandPrintBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPrintBarButtonItem1.Name = "diagramCommandPrintBarButtonItem1";
            // 
            // diagramCommandQuickPrintBarButtonItem1
            // 
            this.diagramCommandQuickPrintBarButtonItem1.Id = 8;
            this.diagramCommandQuickPrintBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandQuickPrintBarButtonItem1.Name = "diagramCommandQuickPrintBarButtonItem1";
            // 
            // diagramCommandExportAsBarSplitButtonItem1
            // 
            this.diagramCommandExportAsBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandExportAsBarSplitButtonItem1.DropDownControl = this.ExportAsPopupMenu;
            this.diagramCommandExportAsBarSplitButtonItem1.Id = 9;
            this.diagramCommandExportAsBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandExportAsBarSplitButtonItem1.Name = "diagramCommandExportAsBarSplitButtonItem1";
            // 
            // ExportAsPopupMenu
            // 
            this.ExportAsPopupMenu.ItemLinks.Add(this.diagramCommandExportDiagram_PNGBarButtonItem1);
            this.ExportAsPopupMenu.ItemLinks.Add(this.diagramCommandExportDiagram_JPEGBarButtonItem1);
            this.ExportAsPopupMenu.ItemLinks.Add(this.diagramCommandExportDiagram_BMPBarButtonItem1);
            this.ExportAsPopupMenu.ItemLinks.Add(this.diagramCommandExportDiagram_GIFBarButtonItem1);
            this.ExportAsPopupMenu.Name = "ExportAsPopupMenu";
            this.ExportAsPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandExportDiagram_PNGBarButtonItem1
            // 
            this.diagramCommandExportDiagram_PNGBarButtonItem1.Id = 10;
            this.diagramCommandExportDiagram_PNGBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandExportDiagram_PNGBarButtonItem1.Name = "diagramCommandExportDiagram_PNGBarButtonItem1";
            // 
            // diagramCommandExportDiagram_JPEGBarButtonItem1
            // 
            this.diagramCommandExportDiagram_JPEGBarButtonItem1.Id = 11;
            this.diagramCommandExportDiagram_JPEGBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandExportDiagram_JPEGBarButtonItem1.Name = "diagramCommandExportDiagram_JPEGBarButtonItem1";
            this.diagramCommandExportDiagram_JPEGBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandExportDiagram_BMPBarButtonItem1
            // 
            this.diagramCommandExportDiagram_BMPBarButtonItem1.Id = 12;
            this.diagramCommandExportDiagram_BMPBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandExportDiagram_BMPBarButtonItem1.Name = "diagramCommandExportDiagram_BMPBarButtonItem1";
            this.diagramCommandExportDiagram_BMPBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandExportDiagram_GIFBarButtonItem1
            // 
            this.diagramCommandExportDiagram_GIFBarButtonItem1.Id = 13;
            this.diagramCommandExportDiagram_GIFBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandExportDiagram_GIFBarButtonItem1.Name = "diagramCommandExportDiagram_GIFBarButtonItem1";
            this.diagramCommandExportDiagram_GIFBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // barAndDockingController1
            // 
            this.barAndDockingController1.PropertiesBar.DefaultGlyphSize = new System.Drawing.Size(16, 16);
            this.barAndDockingController1.PropertiesBar.DefaultLargeGlyphSize = new System.Drawing.Size(32, 32);
            this.barAndDockingController1.PropertiesRibbon.ScaleEditors = true;
            // 
            // diagramCommandUndoBarButtonItem1
            // 
            this.diagramCommandUndoBarButtonItem1.Id = 14;
            this.diagramCommandUndoBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandUndoBarButtonItem1.Name = "diagramCommandUndoBarButtonItem1";
            // 
            // diagramCommandRedoBarButtonItem1
            // 
            this.diagramCommandRedoBarButtonItem1.Id = 15;
            this.diagramCommandRedoBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandRedoBarButtonItem1.Name = "diagramCommandRedoBarButtonItem1";
            // 
            // diagramStatusBarShapeInfoBarStaticItem1
            // 
            this.diagramStatusBarShapeInfoBarStaticItem1.Id = 16;
            this.diagramStatusBarShapeInfoBarStaticItem1.Name = "diagramStatusBarShapeInfoBarStaticItem1";
            toolTipTitleItem1.Text = "Shape Info";
            superToolTip1.Items.Add(toolTipTitleItem1);
            this.diagramStatusBarShapeInfoBarStaticItem1.SuperTip = superToolTip1;
            this.diagramStatusBarShapeInfoBarStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // diagramCommandStatusBarZoomEditorBarEditItem1
            // 
            this.diagramCommandStatusBarZoomEditorBarEditItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.diagramCommandStatusBarZoomEditorBarEditItem1.Edit = this.diagramRepositoryItemZoomTrackBar1;
            this.diagramCommandStatusBarZoomEditorBarEditItem1.EditWidth = 100;
            this.diagramCommandStatusBarZoomEditorBarEditItem1.Id = 17;
            this.diagramCommandStatusBarZoomEditorBarEditItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandStatusBarZoomEditorBarEditItem1.Name = "diagramCommandStatusBarZoomEditorBarEditItem1";
            // 
            // diagramRepositoryItemZoomTrackBar1
            // 
            this.diagramRepositoryItemZoomTrackBar1.LabelAppearance.Options.UseTextOptions = true;
            this.diagramRepositoryItemZoomTrackBar1.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.diagramRepositoryItemZoomTrackBar1.LargeChange = 240;
            this.diagramRepositoryItemZoomTrackBar1.Maximum = 3600;
            this.diagramRepositoryItemZoomTrackBar1.Minimum = -3600;
            this.diagramRepositoryItemZoomTrackBar1.Name = "diagramRepositoryItemZoomTrackBar1";
            this.diagramRepositoryItemZoomTrackBar1.SmallChange = 120;
            this.diagramRepositoryItemZoomTrackBar1.SmallChangeUseMode = DevExpress.XtraEditors.Repository.SmallChangeUseMode.ArrowKeysAndMouse;
            // 
            // diagramCommandContainerPaddingBarDropDownItem1
            // 
            this.diagramCommandContainerPaddingBarDropDownItem1.Id = 18;
            this.diagramCommandContainerPaddingBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPaddingBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P0BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P4BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P8BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P12BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P16BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P24BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerPadding_P32BarCheckItem1)});
            this.diagramCommandContainerPaddingBarDropDownItem1.Name = "diagramCommandContainerPaddingBarDropDownItem1";
            // 
            // diagramCommandContainerPadding_P0BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P0BarCheckItem1.Id = 20;
            this.diagramCommandContainerPadding_P0BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P0BarCheckItem1.Name = "diagramCommandContainerPadding_P0BarCheckItem1";
            toolTipTitleItem2.Text = "0 px.";
            superToolTip2.Items.Add(toolTipTitleItem2);
            this.diagramCommandContainerPadding_P0BarCheckItem1.SuperTip = superToolTip2;
            // 
            // diagramCommandContainerPadding_P4BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P4BarCheckItem1.Id = 21;
            this.diagramCommandContainerPadding_P4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P4BarCheckItem1.Name = "diagramCommandContainerPadding_P4BarCheckItem1";
            toolTipTitleItem3.Text = "4 px.";
            superToolTip3.Items.Add(toolTipTitleItem3);
            this.diagramCommandContainerPadding_P4BarCheckItem1.SuperTip = superToolTip3;
            // 
            // diagramCommandContainerPadding_P8BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P8BarCheckItem1.Id = 22;
            this.diagramCommandContainerPadding_P8BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P8BarCheckItem1.Name = "diagramCommandContainerPadding_P8BarCheckItem1";
            toolTipTitleItem4.Text = "8 px.";
            superToolTip4.Items.Add(toolTipTitleItem4);
            this.diagramCommandContainerPadding_P8BarCheckItem1.SuperTip = superToolTip4;
            // 
            // diagramCommandContainerPadding_P12BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P12BarCheckItem1.Id = 23;
            this.diagramCommandContainerPadding_P12BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P12BarCheckItem1.Name = "diagramCommandContainerPadding_P12BarCheckItem1";
            toolTipTitleItem5.Text = "12 px.";
            superToolTip5.Items.Add(toolTipTitleItem5);
            this.diagramCommandContainerPadding_P12BarCheckItem1.SuperTip = superToolTip5;
            // 
            // diagramCommandContainerPadding_P16BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P16BarCheckItem1.Id = 24;
            this.diagramCommandContainerPadding_P16BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P16BarCheckItem1.Name = "diagramCommandContainerPadding_P16BarCheckItem1";
            toolTipTitleItem6.Text = "16 px.";
            superToolTip6.Items.Add(toolTipTitleItem6);
            this.diagramCommandContainerPadding_P16BarCheckItem1.SuperTip = superToolTip6;
            // 
            // diagramCommandContainerPadding_P24BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P24BarCheckItem1.Id = 25;
            this.diagramCommandContainerPadding_P24BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P24BarCheckItem1.Name = "diagramCommandContainerPadding_P24BarCheckItem1";
            toolTipTitleItem7.Text = "24 px.";
            superToolTip7.Items.Add(toolTipTitleItem7);
            this.diagramCommandContainerPadding_P24BarCheckItem1.SuperTip = superToolTip7;
            // 
            // diagramCommandContainerPadding_P32BarCheckItem1
            // 
            this.diagramCommandContainerPadding_P32BarCheckItem1.Id = 26;
            this.diagramCommandContainerPadding_P32BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerPadding_P32BarCheckItem1.Name = "diagramCommandContainerPadding_P32BarCheckItem1";
            toolTipTitleItem8.Text = "32 px.";
            superToolTip8.Items.Add(toolTipTitleItem8);
            this.diagramCommandContainerPadding_P32BarCheckItem1.SuperTip = superToolTip8;
            // 
            // diagramCommandContainerHeaderPaddingBarDropDownItem1
            // 
            this.diagramCommandContainerHeaderPaddingBarDropDownItem1.Id = 19;
            this.diagramCommandContainerHeaderPaddingBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPaddingBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P0BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P4BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P8BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P12BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P16BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P24BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandContainerHeaderPadding_P32BarCheckItem1)});
            this.diagramCommandContainerHeaderPaddingBarDropDownItem1.Name = "diagramCommandContainerHeaderPaddingBarDropDownItem1";
            // 
            // diagramCommandContainerHeaderPadding_P0BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P0BarCheckItem1.Id = 27;
            this.diagramCommandContainerHeaderPadding_P0BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P0BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P0BarCheckItem1";
            toolTipTitleItem9.Text = "0 px.";
            superToolTip9.Items.Add(toolTipTitleItem9);
            this.diagramCommandContainerHeaderPadding_P0BarCheckItem1.SuperTip = superToolTip9;
            // 
            // diagramCommandContainerHeaderPadding_P4BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P4BarCheckItem1.Id = 28;
            this.diagramCommandContainerHeaderPadding_P4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P4BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P4BarCheckItem1";
            toolTipTitleItem10.Text = "4 px.";
            superToolTip10.Items.Add(toolTipTitleItem10);
            this.diagramCommandContainerHeaderPadding_P4BarCheckItem1.SuperTip = superToolTip10;
            // 
            // diagramCommandContainerHeaderPadding_P8BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P8BarCheckItem1.Id = 29;
            this.diagramCommandContainerHeaderPadding_P8BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P8BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P8BarCheckItem1";
            toolTipTitleItem11.Text = "8 px.";
            superToolTip11.Items.Add(toolTipTitleItem11);
            this.diagramCommandContainerHeaderPadding_P8BarCheckItem1.SuperTip = superToolTip11;
            // 
            // diagramCommandContainerHeaderPadding_P12BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P12BarCheckItem1.Id = 30;
            this.diagramCommandContainerHeaderPadding_P12BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P12BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P12BarCheckItem1";
            toolTipTitleItem12.Text = "12 px.";
            superToolTip12.Items.Add(toolTipTitleItem12);
            this.diagramCommandContainerHeaderPadding_P12BarCheckItem1.SuperTip = superToolTip12;
            // 
            // diagramCommandContainerHeaderPadding_P16BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P16BarCheckItem1.Id = 31;
            this.diagramCommandContainerHeaderPadding_P16BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P16BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P16BarCheckItem1";
            toolTipTitleItem13.Text = "16 px.";
            superToolTip13.Items.Add(toolTipTitleItem13);
            this.diagramCommandContainerHeaderPadding_P16BarCheckItem1.SuperTip = superToolTip13;
            // 
            // diagramCommandContainerHeaderPadding_P24BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P24BarCheckItem1.Id = 32;
            this.diagramCommandContainerHeaderPadding_P24BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P24BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P24BarCheckItem1";
            toolTipTitleItem14.Text = "24 px.";
            superToolTip14.Items.Add(toolTipTitleItem14);
            this.diagramCommandContainerHeaderPadding_P24BarCheckItem1.SuperTip = superToolTip14;
            // 
            // diagramCommandContainerHeaderPadding_P32BarCheckItem1
            // 
            this.diagramCommandContainerHeaderPadding_P32BarCheckItem1.Id = 33;
            this.diagramCommandContainerHeaderPadding_P32BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandContainerHeaderPadding_P32BarCheckItem1.Name = "diagramCommandContainerHeaderPadding_P32BarCheckItem1";
            toolTipTitleItem15.Text = "32 px.";
            superToolTip15.Items.Add(toolTipTitleItem15);
            this.diagramCommandContainerHeaderPadding_P32BarCheckItem1.SuperTip = superToolTip15;
            // 
            // diagramCommandContainerStylesBarGalleryItem1
            // 
            // 
            // 
            // 
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.ColumnCount = 6;
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1});
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            skinPaddingEdges1.Left = 5;
            skinPaddingEdges1.Right = 5;
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.ItemImagePadding = skinPaddingEdges1;
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.RowCount = 1;
            this.diagramCommandContainerStylesBarGalleryItem1.Gallery.ScaleImages = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandContainerStylesBarGalleryItem1.Id = 34;
            this.diagramCommandContainerStylesBarGalleryItem1.Name = "diagramCommandContainerStylesBarGalleryItem1";
            // 
            // diagramCommandShowContainerHeaderBarCheckItem1
            // 
            this.diagramCommandShowContainerHeaderBarCheckItem1.Id = 35;
            this.diagramCommandShowContainerHeaderBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandShowContainerHeaderBarCheckItem1.Name = "diagramCommandShowContainerHeaderBarCheckItem1";
            // 
            // diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1
            // 
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.DropDownControl = this.ImageToolsBringToFrontContainerPopupMenu;
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.Id = 36;
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1.Name = "diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1";
            // 
            // ImageToolsBringToFrontContainerPopupMenu
            // 
            this.ImageToolsBringToFrontContainerPopupMenu.ItemLinks.Add(this.diagramCommandBringForwardBarButtonItem1);
            this.ImageToolsBringToFrontContainerPopupMenu.ItemLinks.Add(this.diagramCommandBringToFrontBarButtonItem1);
            this.ImageToolsBringToFrontContainerPopupMenu.Name = "ImageToolsBringToFrontContainerPopupMenu";
            this.ImageToolsBringToFrontContainerPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandBringForwardBarButtonItem1
            // 
            this.diagramCommandBringForwardBarButtonItem1.Id = 38;
            this.diagramCommandBringForwardBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandBringForwardBarButtonItem1.Name = "diagramCommandBringForwardBarButtonItem1";
            // 
            // diagramCommandBringToFrontBarButtonItem1
            // 
            this.diagramCommandBringToFrontBarButtonItem1.Id = 39;
            this.diagramCommandBringToFrontBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandBringToFrontBarButtonItem1.Name = "diagramCommandBringToFrontBarButtonItem1";
            // 
            // diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1
            // 
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.DropDownControl = this.ImageToolsSendToBackContainerPopupMenu;
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.Id = 37;
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1.Name = "diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1";
            // 
            // ImageToolsSendToBackContainerPopupMenu
            // 
            this.ImageToolsSendToBackContainerPopupMenu.ItemLinks.Add(this.diagramCommandSendBackwardBarButtonItem1);
            this.ImageToolsSendToBackContainerPopupMenu.ItemLinks.Add(this.diagramCommandSendToBackBarButtonItem1);
            this.ImageToolsSendToBackContainerPopupMenu.Name = "ImageToolsSendToBackContainerPopupMenu";
            this.ImageToolsSendToBackContainerPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandSendBackwardBarButtonItem1
            // 
            this.diagramCommandSendBackwardBarButtonItem1.Id = 40;
            this.diagramCommandSendBackwardBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSendBackwardBarButtonItem1.Name = "diagramCommandSendBackwardBarButtonItem1";
            // 
            // diagramCommandSendToBackBarButtonItem1
            // 
            this.diagramCommandSendToBackBarButtonItem1.Id = 41;
            this.diagramCommandSendToBackBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSendToBackBarButtonItem1.Name = "diagramCommandSendToBackBarButtonItem1";
            // 
            // diagramCommandImageToolsRotateBarDropDownItem1
            // 
            this.diagramCommandImageToolsRotateBarDropDownItem1.Id = 42;
            this.diagramCommandImageToolsRotateBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsRotateBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandRotate_Right90BarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandRotate_Left90BarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandFlipImage_VerticalBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandFlipImage_HorizontalBarButtonItem1)});
            this.diagramCommandImageToolsRotateBarDropDownItem1.Name = "diagramCommandImageToolsRotateBarDropDownItem1";
            // 
            // diagramCommandRotate_Right90BarButtonItem1
            // 
            this.diagramCommandRotate_Right90BarButtonItem1.Id = 47;
            this.diagramCommandRotate_Right90BarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandRotate_Right90BarButtonItem1.Name = "diagramCommandRotate_Right90BarButtonItem1";
            // 
            // diagramCommandRotate_Left90BarButtonItem1
            // 
            this.diagramCommandRotate_Left90BarButtonItem1.Id = 48;
            this.diagramCommandRotate_Left90BarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandRotate_Left90BarButtonItem1.Name = "diagramCommandRotate_Left90BarButtonItem1";
            // 
            // diagramCommandFlipImage_VerticalBarButtonItem1
            // 
            this.diagramCommandFlipImage_VerticalBarButtonItem1.Id = 49;
            this.diagramCommandFlipImage_VerticalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFlipImage_VerticalBarButtonItem1.Name = "diagramCommandFlipImage_VerticalBarButtonItem1";
            // 
            // diagramCommandFlipImage_HorizontalBarButtonItem1
            // 
            this.diagramCommandFlipImage_HorizontalBarButtonItem1.Id = 50;
            this.diagramCommandFlipImage_HorizontalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFlipImage_HorizontalBarButtonItem1.Name = "diagramCommandFlipImage_HorizontalBarButtonItem1";
            // 
            // diagramCommandImageToolsStretchModeBarDropDownItem1
            // 
            this.diagramCommandImageToolsStretchModeBarDropDownItem1.Id = 43;
            this.diagramCommandImageToolsStretchModeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsStretchModeBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1)});
            this.diagramCommandImageToolsStretchModeBarDropDownItem1.Name = "diagramCommandImageToolsStretchModeBarDropDownItem1";
            // 
            // diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1
            // 
            this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.Id = 51;
            this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1.Name = "diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1";
            // 
            // diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1
            // 
            this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.Id = 52;
            this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1.Name = "diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1";
            // 
            // diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1
            // 
            this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.Id = 53;
            this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1.Name = "diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1";
            // 
            // diagramCommandImageToolsSetImageScaleBarDropDownItem1
            // 
            this.diagramCommandImageToolsSetImageScaleBarDropDownItem1.Id = 44;
            this.diagramCommandImageToolsSetImageScaleBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScaleBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_1BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_2BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandImageToolsSetImageScale_4BarCheckItem1)});
            this.diagramCommandImageToolsSetImageScaleBarDropDownItem1.Name = "diagramCommandImageToolsSetImageScaleBarDropDownItem1";
            // 
            // diagramCommandImageToolsSetImageScale_0_25BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.Id = 54;
            this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_0_25BarCheckItem1";
            toolTipTitleItem16.Text = "25 %";
            superToolTip16.Items.Add(toolTipTitleItem16);
            this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1.SuperTip = superToolTip16;
            // 
            // diagramCommandImageToolsSetImageScale_0_5BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.Id = 55;
            this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_0_5BarCheckItem1";
            toolTipTitleItem17.Text = "50 %";
            superToolTip17.Items.Add(toolTipTitleItem17);
            this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1.SuperTip = superToolTip17;
            // 
            // diagramCommandImageToolsSetImageScale_0_75BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.Id = 56;
            this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_0_75BarCheckItem1";
            toolTipTitleItem18.Text = "75 %";
            superToolTip18.Items.Add(toolTipTitleItem18);
            this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1.SuperTip = superToolTip18;
            // 
            // diagramCommandImageToolsSetImageScale_1BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_1BarCheckItem1.Id = 57;
            this.diagramCommandImageToolsSetImageScale_1BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_1BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_1BarCheckItem1";
            toolTipTitleItem19.Text = "100 %";
            superToolTip19.Items.Add(toolTipTitleItem19);
            this.diagramCommandImageToolsSetImageScale_1BarCheckItem1.SuperTip = superToolTip19;
            // 
            // diagramCommandImageToolsSetImageScale_1_5BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.Id = 58;
            this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_1_5BarCheckItem1";
            toolTipTitleItem20.Text = "150 %";
            superToolTip20.Items.Add(toolTipTitleItem20);
            this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1.SuperTip = superToolTip20;
            // 
            // diagramCommandImageToolsSetImageScale_2BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_2BarCheckItem1.Id = 59;
            this.diagramCommandImageToolsSetImageScale_2BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_2BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_2BarCheckItem1";
            toolTipTitleItem21.Text = "200 %";
            superToolTip21.Items.Add(toolTipTitleItem21);
            this.diagramCommandImageToolsSetImageScale_2BarCheckItem1.SuperTip = superToolTip21;
            // 
            // diagramCommandImageToolsSetImageScale_4BarCheckItem1
            // 
            this.diagramCommandImageToolsSetImageScale_4BarCheckItem1.Id = 60;
            this.diagramCommandImageToolsSetImageScale_4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandImageToolsSetImageScale_4BarCheckItem1.Name = "diagramCommandImageToolsSetImageScale_4BarCheckItem1";
            toolTipTitleItem22.Text = "400 %";
            superToolTip22.Items.Add(toolTipTitleItem22);
            this.diagramCommandImageToolsSetImageScale_4BarCheckItem1.SuperTip = superToolTip22;
            // 
            // diagramCommandResetSelectedImagesBarButtonItem1
            // 
            this.diagramCommandResetSelectedImagesBarButtonItem1.Id = 45;
            this.diagramCommandResetSelectedImagesBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandResetSelectedImagesBarButtonItem1.Name = "diagramCommandResetSelectedImagesBarButtonItem1";
            // 
            // diagramCommandLoadImageBarButtonItem1
            // 
            this.diagramCommandLoadImageBarButtonItem1.Id = 46;
            this.diagramCommandLoadImageBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandLoadImageBarButtonItem1.Name = "diagramCommandLoadImageBarButtonItem1";
            // 
            // diagramCommandShowRulersBarCheckItem1
            // 
            this.diagramCommandShowRulersBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.diagramCommandShowRulersBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.diagramCommandShowRulersBarCheckItem1.Id = 61;
            this.diagramCommandShowRulersBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandShowRulersBarCheckItem1.Name = "diagramCommandShowRulersBarCheckItem1";
            this.diagramCommandShowRulersBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandShowGridBarCheckItem1
            // 
            this.diagramCommandShowGridBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.diagramCommandShowGridBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.diagramCommandShowGridBarCheckItem1.Id = 62;
            this.diagramCommandShowGridBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandShowGridBarCheckItem1.Name = "diagramCommandShowGridBarCheckItem1";
            this.diagramCommandShowGridBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandShowPageBreaksBarCheckItem1
            // 
            this.diagramCommandShowPageBreaksBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.diagramCommandShowPageBreaksBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.diagramCommandShowPageBreaksBarCheckItem1.Id = 63;
            this.diagramCommandShowPageBreaksBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandShowPageBreaksBarCheckItem1.Name = "diagramCommandShowPageBreaksBarCheckItem1";
            this.diagramCommandShowPageBreaksBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandPanesBarDropDownItem1
            // 
            this.diagramCommandPanesBarDropDownItem1.Id = 64;
            this.diagramCommandPanesBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPanesBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandShapesPanelBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPropertiesPanelBarCheckItem1)});
            this.diagramCommandPanesBarDropDownItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText;
            this.diagramCommandPanesBarDropDownItem1.Name = "diagramCommandPanesBarDropDownItem1";
            this.diagramCommandPanesBarDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandShapesPanelBarCheckItem1
            // 
            this.diagramCommandShapesPanelBarCheckItem1.Id = 65;
            this.diagramCommandShapesPanelBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandShapesPanelBarCheckItem1.Name = "diagramCommandShapesPanelBarCheckItem1";
            this.diagramCommandShapesPanelBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandPropertiesPanelBarCheckItem1
            // 
            this.diagramCommandPropertiesPanelBarCheckItem1.Id = 66;
            this.diagramCommandPropertiesPanelBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPropertiesPanelBarCheckItem1.Name = "diagramCommandPropertiesPanelBarCheckItem1";
            this.diagramCommandPropertiesPanelBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandFitToPageBarButtonItem1
            // 
            this.diagramCommandFitToPageBarButtonItem1.Id = 67;
            this.diagramCommandFitToPageBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFitToPageBarButtonItem1.Name = "diagramCommandFitToPageBarButtonItem1";
            this.diagramCommandFitToPageBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandFitToWidthBarButtonItem1
            // 
            this.diagramCommandFitToWidthBarButtonItem1.Id = 68;
            this.diagramCommandFitToWidthBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFitToWidthBarButtonItem1.Name = "diagramCommandFitToWidthBarButtonItem1";
            this.diagramCommandFitToWidthBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandPageOrientationBarDropDownItem1
            // 
            this.diagramCommandPageOrientationBarDropDownItem1.Id = 69;
            this.diagramCommandPageOrientationBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageOrientationBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageOrientation_HorizontalBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageOrientation_VerticalBarCheckItem1)});
            this.diagramCommandPageOrientationBarDropDownItem1.Name = "diagramCommandPageOrientationBarDropDownItem1";
            // 
            // diagramCommandPageOrientation_HorizontalBarCheckItem1
            // 
            this.diagramCommandPageOrientation_HorizontalBarCheckItem1.Id = 72;
            this.diagramCommandPageOrientation_HorizontalBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageOrientation_HorizontalBarCheckItem1.Name = "diagramCommandPageOrientation_HorizontalBarCheckItem1";
            toolTipTitleItem23.Text = "Landscape";
            superToolTip23.Items.Add(toolTipTitleItem23);
            this.diagramCommandPageOrientation_HorizontalBarCheckItem1.SuperTip = superToolTip23;
            // 
            // diagramCommandPageOrientation_VerticalBarCheckItem1
            // 
            this.diagramCommandPageOrientation_VerticalBarCheckItem1.Id = 73;
            this.diagramCommandPageOrientation_VerticalBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageOrientation_VerticalBarCheckItem1.Name = "diagramCommandPageOrientation_VerticalBarCheckItem1";
            toolTipTitleItem24.Text = "Portrait";
            superToolTip24.Items.Add(toolTipTitleItem24);
            this.diagramCommandPageOrientation_VerticalBarCheckItem1.SuperTip = superToolTip24;
            // 
            // diagramCommandPageSizeBarDropDownItem1
            // 
            this.diagramCommandPageSizeBarDropDownItem1.Id = 70;
            this.diagramCommandPageSizeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSizeBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_LetterBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_TabloidBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_LegalBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_StatementBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_ExecutiveBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_A3BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_A4BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_A5BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_B4BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandPageSize_B5BarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandFitToDrawingBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSetPageParameters_PageSizeBarButtonItem1)});
            this.diagramCommandPageSizeBarDropDownItem1.Name = "diagramCommandPageSizeBarDropDownItem1";
            // 
            // diagramCommandPageSize_LetterBarCheckItem1
            // 
            this.diagramCommandPageSize_LetterBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_LetterBarCheckItem1.Id = 74;
            this.diagramCommandPageSize_LetterBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_LetterBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_LetterBarCheckItem1.Name = "diagramCommandPageSize_LetterBarCheckItem1";
            superToolTip25.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem25.Text = "<b>Letter</b><br>8.5\" x 11\"";
            superToolTip25.Items.Add(toolTipTitleItem25);
            this.diagramCommandPageSize_LetterBarCheckItem1.SuperTip = superToolTip25;
            // 
            // diagramCommandPageSize_TabloidBarCheckItem1
            // 
            this.diagramCommandPageSize_TabloidBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_TabloidBarCheckItem1.Id = 75;
            this.diagramCommandPageSize_TabloidBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_TabloidBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_TabloidBarCheckItem1.Name = "diagramCommandPageSize_TabloidBarCheckItem1";
            superToolTip26.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem26.Text = "<b>Tabloid</b><br>11\" x 17\"";
            superToolTip26.Items.Add(toolTipTitleItem26);
            this.diagramCommandPageSize_TabloidBarCheckItem1.SuperTip = superToolTip26;
            // 
            // diagramCommandPageSize_LegalBarCheckItem1
            // 
            this.diagramCommandPageSize_LegalBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_LegalBarCheckItem1.Id = 76;
            this.diagramCommandPageSize_LegalBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_LegalBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_LegalBarCheckItem1.Name = "diagramCommandPageSize_LegalBarCheckItem1";
            superToolTip27.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem27.Text = "<b>Legal</b><br>8.5\" x 14\"";
            superToolTip27.Items.Add(toolTipTitleItem27);
            this.diagramCommandPageSize_LegalBarCheckItem1.SuperTip = superToolTip27;
            // 
            // diagramCommandPageSize_StatementBarCheckItem1
            // 
            this.diagramCommandPageSize_StatementBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_StatementBarCheckItem1.Id = 77;
            this.diagramCommandPageSize_StatementBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_StatementBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_StatementBarCheckItem1.Name = "diagramCommandPageSize_StatementBarCheckItem1";
            superToolTip28.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem28.Text = "<b>Statement</b><br>5.5\" x 8.5\"";
            superToolTip28.Items.Add(toolTipTitleItem28);
            this.diagramCommandPageSize_StatementBarCheckItem1.SuperTip = superToolTip28;
            // 
            // diagramCommandPageSize_ExecutiveBarCheckItem1
            // 
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.Id = 78;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.Name = "diagramCommandPageSize_ExecutiveBarCheckItem1";
            superToolTip29.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem29.Text = "<b>Executive</b><br>7.25\" x 10.5\"";
            superToolTip29.Items.Add(toolTipTitleItem29);
            this.diagramCommandPageSize_ExecutiveBarCheckItem1.SuperTip = superToolTip29;
            // 
            // diagramCommandPageSize_A3BarCheckItem1
            // 
            this.diagramCommandPageSize_A3BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_A3BarCheckItem1.Id = 79;
            this.diagramCommandPageSize_A3BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_A3BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_A3BarCheckItem1.Name = "diagramCommandPageSize_A3BarCheckItem1";
            superToolTip30.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem30.Text = "<b>A3</b><br>11.7\" x 16.53\"";
            superToolTip30.Items.Add(toolTipTitleItem30);
            this.diagramCommandPageSize_A3BarCheckItem1.SuperTip = superToolTip30;
            // 
            // diagramCommandPageSize_A4BarCheckItem1
            // 
            this.diagramCommandPageSize_A4BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_A4BarCheckItem1.Id = 80;
            this.diagramCommandPageSize_A4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_A4BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_A4BarCheckItem1.Name = "diagramCommandPageSize_A4BarCheckItem1";
            superToolTip31.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem31.Text = "<b>A4</b><br>8.27\" x 11.7\"";
            superToolTip31.Items.Add(toolTipTitleItem31);
            this.diagramCommandPageSize_A4BarCheckItem1.SuperTip = superToolTip31;
            // 
            // diagramCommandPageSize_A5BarCheckItem1
            // 
            this.diagramCommandPageSize_A5BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_A5BarCheckItem1.Id = 81;
            this.diagramCommandPageSize_A5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_A5BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_A5BarCheckItem1.Name = "diagramCommandPageSize_A5BarCheckItem1";
            superToolTip32.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem32.Text = "<b>A5</b><br>5.82\" x 8.27\"";
            superToolTip32.Items.Add(toolTipTitleItem32);
            this.diagramCommandPageSize_A5BarCheckItem1.SuperTip = superToolTip32;
            // 
            // diagramCommandPageSize_B4BarCheckItem1
            // 
            this.diagramCommandPageSize_B4BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_B4BarCheckItem1.Id = 82;
            this.diagramCommandPageSize_B4BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_B4BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_B4BarCheckItem1.Name = "diagramCommandPageSize_B4BarCheckItem1";
            superToolTip33.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem33.Text = "<b>B4 (JIS)</b><br>10.11\" x 14.33\"";
            superToolTip33.Items.Add(toolTipTitleItem33);
            this.diagramCommandPageSize_B4BarCheckItem1.SuperTip = superToolTip33;
            // 
            // diagramCommandPageSize_B5BarCheckItem1
            // 
            this.diagramCommandPageSize_B5BarCheckItem1.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandPageSize_B5BarCheckItem1.Id = 83;
            this.diagramCommandPageSize_B5BarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Normal.Options.UseTextOptions = true;
            this.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Pressed.Options.UseTextOptions = true;
            this.diagramCommandPageSize_B5BarCheckItem1.ItemInMenuAppearance.Pressed.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.diagramCommandPageSize_B5BarCheckItem1.Name = "diagramCommandPageSize_B5BarCheckItem1";
            superToolTip34.AllowHtmlText = DevExpress.Utils.DefaultBoolean.True;
            toolTipTitleItem34.Text = "<b>B5 (JIS)</b><br>7.17\" x 10.11\"";
            superToolTip34.Items.Add(toolTipTitleItem34);
            this.diagramCommandPageSize_B5BarCheckItem1.SuperTip = superToolTip34;
            // 
            // diagramCommandFitToDrawingBarButtonItem1
            // 
            this.diagramCommandFitToDrawingBarButtonItem1.Id = 84;
            this.diagramCommandFitToDrawingBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFitToDrawingBarButtonItem1.Name = "diagramCommandFitToDrawingBarButtonItem1";
            // 
            // diagramCommandSetPageParameters_PageSizeBarButtonItem1
            // 
            this.diagramCommandSetPageParameters_PageSizeBarButtonItem1.Id = 85;
            this.diagramCommandSetPageParameters_PageSizeBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetPageParameters_PageSizeBarButtonItem1.Name = "diagramCommandSetPageParameters_PageSizeBarButtonItem1";
            // 
            // diagramCommandAutoSizeBarDropDownItem1
            // 
            this.diagramCommandAutoSizeBarDropDownItem1.Id = 71;
            this.diagramCommandAutoSizeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandAutoSizeBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandAutoSize_NoneBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandAutoSize_AutoSizeBarCheckItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandAutoSize_FillBarCheckItem1)});
            this.diagramCommandAutoSizeBarDropDownItem1.Name = "diagramCommandAutoSizeBarDropDownItem1";
            // 
            // diagramCommandAutoSize_NoneBarCheckItem1
            // 
            this.diagramCommandAutoSize_NoneBarCheckItem1.Id = 86;
            this.diagramCommandAutoSize_NoneBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandAutoSize_NoneBarCheckItem1.Name = "diagramCommandAutoSize_NoneBarCheckItem1";
            // 
            // diagramCommandAutoSize_AutoSizeBarCheckItem1
            // 
            this.diagramCommandAutoSize_AutoSizeBarCheckItem1.Id = 87;
            this.diagramCommandAutoSize_AutoSizeBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandAutoSize_AutoSizeBarCheckItem1.Name = "diagramCommandAutoSize_AutoSizeBarCheckItem1";
            // 
            // diagramCommandAutoSize_FillBarCheckItem1
            // 
            this.diagramCommandAutoSize_FillBarCheckItem1.Id = 88;
            this.diagramCommandAutoSize_FillBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandAutoSize_FillBarCheckItem1.Name = "diagramCommandAutoSize_FillBarCheckItem1";
            // 
            // diagramCommandThemesBarGalleryItem1
            // 
            // 
            // 
            // 
            this.diagramCommandThemesBarGalleryItem1.Gallery.ColumnCount = 8;
            this.diagramCommandThemesBarGalleryItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup2});
            this.diagramCommandThemesBarGalleryItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.diagramCommandThemesBarGalleryItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.diagramCommandThemesBarGalleryItem1.Gallery.RowCount = 1;
            this.diagramCommandThemesBarGalleryItem1.Gallery.ScaleImages = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandThemesBarGalleryItem1.Id = 89;
            this.diagramCommandThemesBarGalleryItem1.Name = "diagramCommandThemesBarGalleryItem1";
            // 
            // diagramCommandSnapToItemsBarCheckItem1
            // 
            this.diagramCommandSnapToItemsBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.diagramCommandSnapToItemsBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.diagramCommandSnapToItemsBarCheckItem1.Id = 90;
            this.diagramCommandSnapToItemsBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSnapToItemsBarCheckItem1.Name = "diagramCommandSnapToItemsBarCheckItem1";
            // 
            // diagramCommandSnapToGridBarCheckItem1
            // 
            this.diagramCommandSnapToGridBarCheckItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.diagramCommandSnapToGridBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.diagramCommandSnapToGridBarCheckItem1.Id = 91;
            this.diagramCommandSnapToGridBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSnapToGridBarCheckItem1.Name = "diagramCommandSnapToGridBarCheckItem1";
            // 
            // diagramCommandReLayoutBarDropDownItem1
            // 
            this.diagramCommandReLayoutBarDropDownItem1.Id = 92;
            this.diagramCommandReLayoutBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandReLayoutBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutTreeBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayout_DownBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayout_UpBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayout_RightBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayout_LeftBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutTipOverTreeHeaderBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutMindMapTreeHeaderBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutSugiyamaBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSugiyamaLayout_DownBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSugiyamaLayout_UpBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSugiyamaLayout_RightBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandSugiyamaLayout_LeftBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutCircularHeaderBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandCircularLayoutBarButtonItem1)});
            this.diagramCommandReLayoutBarDropDownItem1.MultiColumn = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandReLayoutBarDropDownItem1.Name = "diagramCommandReLayoutBarDropDownItem1";
            // 
            // diagramReLayoutTreeBarHeaderItem1
            // 
            this.diagramReLayoutTreeBarHeaderItem1.Id = 95;
            this.diagramReLayoutTreeBarHeaderItem1.Name = "diagramReLayoutTreeBarHeaderItem1";
            // 
            // diagramCommandTreeLayout_DownBarButtonItem1
            // 
            this.diagramCommandTreeLayout_DownBarButtonItem1.Id = 96;
            this.diagramCommandTreeLayout_DownBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayout_DownBarButtonItem1.Name = "diagramCommandTreeLayout_DownBarButtonItem1";
            toolTipTitleItem35.Text = "Top To Bottom";
            superToolTip35.Items.Add(toolTipTitleItem35);
            this.diagramCommandTreeLayout_DownBarButtonItem1.SuperTip = superToolTip35;
            // 
            // diagramCommandTreeLayout_UpBarButtonItem1
            // 
            this.diagramCommandTreeLayout_UpBarButtonItem1.Id = 97;
            this.diagramCommandTreeLayout_UpBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayout_UpBarButtonItem1.Name = "diagramCommandTreeLayout_UpBarButtonItem1";
            toolTipTitleItem36.Text = "Bottom To Top";
            superToolTip36.Items.Add(toolTipTitleItem36);
            this.diagramCommandTreeLayout_UpBarButtonItem1.SuperTip = superToolTip36;
            // 
            // diagramCommandTreeLayout_RightBarButtonItem1
            // 
            this.diagramCommandTreeLayout_RightBarButtonItem1.Id = 98;
            this.diagramCommandTreeLayout_RightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayout_RightBarButtonItem1.Name = "diagramCommandTreeLayout_RightBarButtonItem1";
            toolTipTitleItem37.Text = "Left To Right";
            superToolTip37.Items.Add(toolTipTitleItem37);
            this.diagramCommandTreeLayout_RightBarButtonItem1.SuperTip = superToolTip37;
            // 
            // diagramCommandTreeLayout_LeftBarButtonItem1
            // 
            this.diagramCommandTreeLayout_LeftBarButtonItem1.Id = 99;
            this.diagramCommandTreeLayout_LeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayout_LeftBarButtonItem1.Name = "diagramCommandTreeLayout_LeftBarButtonItem1";
            toolTipTitleItem38.Text = "Right To Left";
            superToolTip38.Items.Add(toolTipTitleItem38);
            this.diagramCommandTreeLayout_LeftBarButtonItem1.SuperTip = superToolTip38;
            // 
            // diagramReLayoutTipOverTreeHeaderBarHeaderItem1
            // 
            this.diagramReLayoutTipOverTreeHeaderBarHeaderItem1.Id = 100;
            this.diagramReLayoutTipOverTreeHeaderBarHeaderItem1.Name = "diagramReLayoutTipOverTreeHeaderBarHeaderItem1";
            // 
            // diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1
            // 
            this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.Id = 101;
            this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.Name = "diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1";
            toolTipTitleItem39.Text = "Left To Right";
            superToolTip39.Items.Add(toolTipTitleItem39);
            this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1.SuperTip = superToolTip39;
            // 
            // diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1
            // 
            this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.Id = 102;
            this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.Name = "diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1";
            toolTipTitleItem40.Text = "Right To Left";
            superToolTip40.Items.Add(toolTipTitleItem40);
            this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1.SuperTip = superToolTip40;
            // 
            // diagramReLayoutMindMapTreeHeaderBarHeaderItem1
            // 
            this.diagramReLayoutMindMapTreeHeaderBarHeaderItem1.Id = 103;
            this.diagramReLayoutMindMapTreeHeaderBarHeaderItem1.Name = "diagramReLayoutMindMapTreeHeaderBarHeaderItem1";
            // 
            // diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1
            // 
            this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1.Id = 104;
            this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1.Name = "diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1";
            toolTipTitleItem41.Text = "Horizontal";
            superToolTip41.Items.Add(toolTipTitleItem41);
            this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1.SuperTip = superToolTip41;
            // 
            // diagramCommandMindMapTreeLayout_VerticalBarButtonItem1
            // 
            this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1.Id = 105;
            this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1.Name = "diagramCommandMindMapTreeLayout_VerticalBarButtonItem1";
            toolTipTitleItem42.Text = "Vertical";
            superToolTip42.Items.Add(toolTipTitleItem42);
            this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1.SuperTip = superToolTip42;
            // 
            // diagramReLayoutSugiyamaBarHeaderItem1
            // 
            this.diagramReLayoutSugiyamaBarHeaderItem1.Id = 106;
            this.diagramReLayoutSugiyamaBarHeaderItem1.Name = "diagramReLayoutSugiyamaBarHeaderItem1";
            // 
            // diagramCommandSugiyamaLayout_DownBarButtonItem1
            // 
            this.diagramCommandSugiyamaLayout_DownBarButtonItem1.Id = 107;
            this.diagramCommandSugiyamaLayout_DownBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSugiyamaLayout_DownBarButtonItem1.Name = "diagramCommandSugiyamaLayout_DownBarButtonItem1";
            toolTipTitleItem43.Text = "Top To Bottom";
            superToolTip43.Items.Add(toolTipTitleItem43);
            this.diagramCommandSugiyamaLayout_DownBarButtonItem1.SuperTip = superToolTip43;
            // 
            // diagramCommandSugiyamaLayout_UpBarButtonItem1
            // 
            this.diagramCommandSugiyamaLayout_UpBarButtonItem1.Id = 108;
            this.diagramCommandSugiyamaLayout_UpBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSugiyamaLayout_UpBarButtonItem1.Name = "diagramCommandSugiyamaLayout_UpBarButtonItem1";
            toolTipTitleItem44.Text = "Bottom To Top";
            superToolTip44.Items.Add(toolTipTitleItem44);
            this.diagramCommandSugiyamaLayout_UpBarButtonItem1.SuperTip = superToolTip44;
            // 
            // diagramCommandSugiyamaLayout_RightBarButtonItem1
            // 
            this.diagramCommandSugiyamaLayout_RightBarButtonItem1.Id = 109;
            this.diagramCommandSugiyamaLayout_RightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSugiyamaLayout_RightBarButtonItem1.Name = "diagramCommandSugiyamaLayout_RightBarButtonItem1";
            toolTipTitleItem45.Text = "Left To Right";
            superToolTip45.Items.Add(toolTipTitleItem45);
            this.diagramCommandSugiyamaLayout_RightBarButtonItem1.SuperTip = superToolTip45;
            // 
            // diagramCommandSugiyamaLayout_LeftBarButtonItem1
            // 
            this.diagramCommandSugiyamaLayout_LeftBarButtonItem1.Id = 110;
            this.diagramCommandSugiyamaLayout_LeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSugiyamaLayout_LeftBarButtonItem1.Name = "diagramCommandSugiyamaLayout_LeftBarButtonItem1";
            toolTipTitleItem46.Text = "Right To Left";
            superToolTip46.Items.Add(toolTipTitleItem46);
            this.diagramCommandSugiyamaLayout_LeftBarButtonItem1.SuperTip = superToolTip46;
            // 
            // diagramReLayoutCircularHeaderBarHeaderItem1
            // 
            this.diagramReLayoutCircularHeaderBarHeaderItem1.Id = 111;
            this.diagramReLayoutCircularHeaderBarHeaderItem1.Name = "diagramReLayoutCircularHeaderBarHeaderItem1";
            // 
            // diagramCommandCircularLayoutBarButtonItem1
            // 
            this.diagramCommandCircularLayoutBarButtonItem1.Id = 112;
            this.diagramCommandCircularLayoutBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandCircularLayoutBarButtonItem1.Name = "diagramCommandCircularLayoutBarButtonItem1";
            toolTipTitleItem47.Text = "Circular";
            superToolTip47.Items.Add(toolTipTitleItem47);
            this.diagramCommandCircularLayoutBarButtonItem1.SuperTip = superToolTip47;
            // 
            // diagramCommandChangeConnectorTypeBarDropDownItem1
            // 
            this.diagramCommandChangeConnectorTypeBarDropDownItem1.Id = 93;
            this.diagramCommandChangeConnectorTypeBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandChangeConnectorTypeBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandChangeConnectorType_CurvedBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandChangeConnectorType_StraightBarButtonItem1)});
            this.diagramCommandChangeConnectorTypeBarDropDownItem1.Name = "diagramCommandChangeConnectorTypeBarDropDownItem1";
            // 
            // diagramCommandChangeConnectorType_RightAngleBarButtonItem1
            // 
            this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1.Id = 113;
            this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1.Name = "diagramCommandChangeConnectorType_RightAngleBarButtonItem1";
            toolTipTitleItem48.Text = "Right Angle";
            superToolTip48.Items.Add(toolTipTitleItem48);
            this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1.SuperTip = superToolTip48;
            // 
            // diagramCommandChangeConnectorType_CurvedBarButtonItem1
            // 
            this.diagramCommandChangeConnectorType_CurvedBarButtonItem1.Id = 114;
            this.diagramCommandChangeConnectorType_CurvedBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandChangeConnectorType_CurvedBarButtonItem1.Name = "diagramCommandChangeConnectorType_CurvedBarButtonItem1";
            toolTipTitleItem49.Text = "Curved";
            superToolTip49.Items.Add(toolTipTitleItem49);
            this.diagramCommandChangeConnectorType_CurvedBarButtonItem1.SuperTip = superToolTip49;
            // 
            // diagramCommandChangeConnectorType_StraightBarButtonItem1
            // 
            this.diagramCommandChangeConnectorType_StraightBarButtonItem1.Id = 115;
            this.diagramCommandChangeConnectorType_StraightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandChangeConnectorType_StraightBarButtonItem1.Name = "diagramCommandChangeConnectorType_StraightBarButtonItem1";
            toolTipTitleItem50.Text = "Straight";
            superToolTip50.Items.Add(toolTipTitleItem50);
            this.diagramCommandChangeConnectorType_StraightBarButtonItem1.SuperTip = superToolTip50;
            // 
            // diagramCommandReLayoutPartsBarDropDownItem1
            // 
            this.diagramCommandReLayoutPartsBarDropDownItem1.Id = 94;
            this.diagramCommandReLayoutPartsBarDropDownItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandReLayoutPartsBarDropDownItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutPartsTreeHeaderBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1)});
            this.diagramCommandReLayoutPartsBarDropDownItem1.MultiColumn = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandReLayoutPartsBarDropDownItem1.Name = "diagramCommandReLayoutPartsBarDropDownItem1";
            // 
            // diagramReLayoutPartsTreeHeaderBarHeaderItem1
            // 
            this.diagramReLayoutPartsTreeHeaderBarHeaderItem1.Id = 116;
            this.diagramReLayoutPartsTreeHeaderBarHeaderItem1.Name = "diagramReLayoutPartsTreeHeaderBarHeaderItem1";
            // 
            // diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1
            // 
            this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1.Id = 117;
            this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1.Name = "diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1";
            toolTipTitleItem51.Text = "Top To Bottom";
            superToolTip51.Items.Add(toolTipTitleItem51);
            this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1.SuperTip = superToolTip51;
            // 
            // diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1
            // 
            this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1.Id = 118;
            this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1.Name = "diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1";
            toolTipTitleItem52.Text = "Bottom To Top";
            superToolTip52.Items.Add(toolTipTitleItem52);
            this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1.SuperTip = superToolTip52;
            // 
            // diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1
            // 
            this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1.Id = 119;
            this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1.Name = "diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1";
            toolTipTitleItem53.Text = "Left To Right";
            superToolTip53.Items.Add(toolTipTitleItem53);
            this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1.SuperTip = superToolTip53;
            // 
            // diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1
            // 
            this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1.Id = 120;
            this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1.Name = "diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1";
            toolTipTitleItem54.Text = "Right To Left";
            superToolTip54.Items.Add(toolTipTitleItem54);
            this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1.SuperTip = superToolTip54;
            // 
            // diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1
            // 
            this.diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1.Id = 121;
            this.diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1.Name = "diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1";
            // 
            // diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1
            // 
            this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1.Id = 122;
            this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1.Name = "diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1";
            toolTipTitleItem55.Text = "Left To Right";
            superToolTip55.Items.Add(toolTipTitleItem55);
            this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1.SuperTip = superToolTip55;
            // 
            // diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1
            // 
            this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1.Id = 123;
            this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1.Name = "diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1";
            toolTipTitleItem56.Text = "Right To Left";
            superToolTip56.Items.Add(toolTipTitleItem56);
            this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1.SuperTip = superToolTip56;
            // 
            // diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1
            // 
            this.diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1.Id = 124;
            this.diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1.Name = "diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1";
            // 
            // diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1
            // 
            this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1.Id = 125;
            this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1.Name = "diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1";
            toolTipTitleItem57.Text = "Horizontal";
            superToolTip57.Items.Add(toolTipTitleItem57);
            this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1.SuperTip = superToolTip57;
            // 
            // diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1
            // 
            this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1.Id = 126;
            this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1.Name = "diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1";
            toolTipTitleItem58.Text = "Vertical";
            superToolTip58.Items.Add(toolTipTitleItem58);
            this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1.SuperTip = superToolTip58;
            // 
            // diagramCommandInsertContainerBarSplitButtonItem1
            // 
            this.diagramCommandInsertContainerBarSplitButtonItem1.DropDownControl = this.InsertContainerPopupMenu;
            this.diagramCommandInsertContainerBarSplitButtonItem1.Id = 127;
            this.diagramCommandInsertContainerBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText;
            this.diagramCommandInsertContainerBarSplitButtonItem1.Name = "diagramCommandInsertContainerBarSplitButtonItem1";
            this.diagramCommandInsertContainerBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // InsertContainerPopupMenu
            // 
            // 
            // 
            // 
            this.InsertContainerPopupMenu.Gallery.AllowFilter = false;
            this.InsertContainerPopupMenu.Gallery.ColumnCount = 4;
            this.InsertContainerPopupMenu.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup3});
            this.InsertContainerPopupMenu.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.InsertContainerPopupMenu.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.InsertContainerPopupMenu.Gallery.RowCount = 2;
            this.InsertContainerPopupMenu.Gallery.ScaleImages = DevExpress.Utils.DefaultBoolean.True;
            this.InsertContainerPopupMenu.Gallery.ShowGroupCaption = false;
            this.InsertContainerPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText;
            this.InsertContainerPopupMenu.Name = "InsertContainerPopupMenu";
            this.InsertContainerPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandInsertImageBarButtonItem1
            // 
            this.diagramCommandInsertImageBarButtonItem1.Id = 128;
            this.diagramCommandInsertImageBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandInsertImageBarButtonItem1.Name = "diagramCommandInsertImageBarButtonItem1";
            this.diagramCommandInsertImageBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandPasteBarButtonItem1
            // 
            this.diagramCommandPasteBarButtonItem1.Id = 133;
            this.diagramCommandPasteBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandPasteBarButtonItem1.Name = "diagramCommandPasteBarButtonItem1";
            this.diagramCommandPasteBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // diagramCommandCutBarButtonItem1
            // 
            this.diagramCommandCutBarButtonItem1.Id = 134;
            this.diagramCommandCutBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandCutBarButtonItem1.Name = "diagramCommandCutBarButtonItem1";
            this.diagramCommandCutBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandCopyBarButtonItem1
            // 
            this.diagramCommandCopyBarButtonItem1.Id = 135;
            this.diagramCommandCopyBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandCopyBarButtonItem1.Name = "diagramCommandCopyBarButtonItem1";
            this.diagramCommandCopyBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Id = 129;
            this.barButtonGroup1.ItemLinks.Add(this.diagramCommandFontFamilyBarEditItem1);
            this.barButtonGroup1.ItemLinks.Add(this.diagramCommandFontSizeBarEditItem1);
            this.barButtonGroup1.ItemLinks.Add(this.diagramCommandIncreaseFontSizeBarButtonItem1);
            this.barButtonGroup1.ItemLinks.Add(this.diagramCommandDecreaseFontSizeBarButtonItem1);
            this.barButtonGroup1.Name = "barButtonGroup1";
            this.barButtonGroup1.Tag = "bgFontSizeAndFamily";
            // 
            // diagramCommandFontFamilyBarEditItem1
            // 
            this.diagramCommandFontFamilyBarEditItem1.Edit = this.repositoryItemFontEdit1;
            this.diagramCommandFontFamilyBarEditItem1.EditWidth = 130;
            this.diagramCommandFontFamilyBarEditItem1.Id = 136;
            this.diagramCommandFontFamilyBarEditItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFontFamilyBarEditItem1.Name = "diagramCommandFontFamilyBarEditItem1";
            // 
            // repositoryItemFontEdit1
            // 
            this.repositoryItemFontEdit1.AutoHeight = false;
            this.repositoryItemFontEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1";
            // 
            // diagramCommandFontSizeBarEditItem1
            // 
            this.diagramCommandFontSizeBarEditItem1.Edit = this.repositoryItemDiagramFontSizeEdit1;
            this.diagramCommandFontSizeBarEditItem1.Id = 137;
            this.diagramCommandFontSizeBarEditItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandFontSizeBarEditItem1.Name = "diagramCommandFontSizeBarEditItem1";
            // 
            // repositoryItemDiagramFontSizeEdit1
            // 
            this.repositoryItemDiagramFontSizeEdit1.AutoHeight = false;
            this.repositoryItemDiagramFontSizeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDiagramFontSizeEdit1.Diagram = this.diagramControl1;
            this.repositoryItemDiagramFontSizeEdit1.Name = "repositoryItemDiagramFontSizeEdit1";
            // 
            // diagramCommandIncreaseFontSizeBarButtonItem1
            // 
            this.diagramCommandIncreaseFontSizeBarButtonItem1.Id = 138;
            this.diagramCommandIncreaseFontSizeBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandIncreaseFontSizeBarButtonItem1.Name = "diagramCommandIncreaseFontSizeBarButtonItem1";
            this.diagramCommandIncreaseFontSizeBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandDecreaseFontSizeBarButtonItem1
            // 
            this.diagramCommandDecreaseFontSizeBarButtonItem1.Id = 139;
            this.diagramCommandDecreaseFontSizeBarButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandDecreaseFontSizeBarButtonItem1.Name = "diagramCommandDecreaseFontSizeBarButtonItem1";
            this.diagramCommandDecreaseFontSizeBarButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Id = 130;
            this.barButtonGroup2.ItemLinks.Add(this.diagramCommandToggleFontBoldBarCheckItem1);
            this.barButtonGroup2.ItemLinks.Add(this.diagramCommandToggleFontItalicBarCheckItem1);
            this.barButtonGroup2.ItemLinks.Add(this.diagramCommandToggleFontUnderlineBarCheckItem1);
            this.barButtonGroup2.ItemLinks.Add(this.diagramCommandToggleFontStrikethroughBarCheckItem1);
            this.barButtonGroup2.ItemLinks.Add(this.diagramCommandForegroundColorBarSplitButtonItem1);
            this.barButtonGroup2.Name = "barButtonGroup2";
            this.barButtonGroup2.Tag = "bgFontTypeAndColor";
            // 
            // diagramCommandToggleFontBoldBarCheckItem1
            // 
            this.diagramCommandToggleFontBoldBarCheckItem1.Id = 140;
            this.diagramCommandToggleFontBoldBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandToggleFontBoldBarCheckItem1.Name = "diagramCommandToggleFontBoldBarCheckItem1";
            this.diagramCommandToggleFontBoldBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandToggleFontItalicBarCheckItem1
            // 
            this.diagramCommandToggleFontItalicBarCheckItem1.Id = 141;
            this.diagramCommandToggleFontItalicBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandToggleFontItalicBarCheckItem1.Name = "diagramCommandToggleFontItalicBarCheckItem1";
            this.diagramCommandToggleFontItalicBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandToggleFontUnderlineBarCheckItem1
            // 
            this.diagramCommandToggleFontUnderlineBarCheckItem1.Id = 142;
            this.diagramCommandToggleFontUnderlineBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandToggleFontUnderlineBarCheckItem1.Name = "diagramCommandToggleFontUnderlineBarCheckItem1";
            this.diagramCommandToggleFontUnderlineBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandToggleFontStrikethroughBarCheckItem1
            // 
            this.diagramCommandToggleFontStrikethroughBarCheckItem1.Id = 143;
            this.diagramCommandToggleFontStrikethroughBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandToggleFontStrikethroughBarCheckItem1.Name = "diagramCommandToggleFontStrikethroughBarCheckItem1";
            this.diagramCommandToggleFontStrikethroughBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandForegroundColorBarSplitButtonItem1
            // 
            this.diagramCommandForegroundColorBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandForegroundColorBarSplitButtonItem1.Color = System.Drawing.Color.Empty;
            this.diagramCommandForegroundColorBarSplitButtonItem1.Id = 144;
            this.diagramCommandForegroundColorBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandForegroundColorBarSplitButtonItem1.Name = "diagramCommandForegroundColorBarSplitButtonItem1";
            this.diagramCommandForegroundColorBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Id = 131;
            this.barButtonGroup3.ItemLinks.Add(this.diagramCommandSetVerticalAlignment_TopBarCheckItem1);
            this.barButtonGroup3.ItemLinks.Add(this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1);
            this.barButtonGroup3.ItemLinks.Add(this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1);
            this.barButtonGroup3.Name = "barButtonGroup3";
            this.barButtonGroup3.Tag = "bgVerticalTextAlignment";
            // 
            // diagramCommandSetVerticalAlignment_TopBarCheckItem1
            // 
            this.diagramCommandSetVerticalAlignment_TopBarCheckItem1.Id = 145;
            this.diagramCommandSetVerticalAlignment_TopBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetVerticalAlignment_TopBarCheckItem1.Name = "diagramCommandSetVerticalAlignment_TopBarCheckItem1";
            this.diagramCommandSetVerticalAlignment_TopBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandSetVerticalAlignment_CenterBarCheckItem1
            // 
            this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.Id = 146;
            this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.Name = "diagramCommandSetVerticalAlignment_CenterBarCheckItem1";
            this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandSetVerticalAlignment_BottomBarCheckItem1
            // 
            this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.Id = 147;
            this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.Name = "diagramCommandSetVerticalAlignment_BottomBarCheckItem1";
            this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Id = 132;
            this.barButtonGroup4.ItemLinks.Add(this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1);
            this.barButtonGroup4.ItemLinks.Add(this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1);
            this.barButtonGroup4.ItemLinks.Add(this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1);
            this.barButtonGroup4.Name = "barButtonGroup4";
            this.barButtonGroup4.Tag = "bgHorizontalTextAlignment";
            // 
            // diagramCommandSetHorizontalAlignment_LeftBarCheckItem1
            // 
            this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.Id = 148;
            this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.Name = "diagramCommandSetHorizontalAlignment_LeftBarCheckItem1";
            this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandSetHorizontalAlignment_CenterBarCheckItem1
            // 
            this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.Id = 149;
            this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.Name = "diagramCommandSetHorizontalAlignment_CenterBarCheckItem1";
            this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandSetHorizontalAlignment_RightBarCheckItem1
            // 
            this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.Id = 150;
            this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.Name = "diagramCommandSetHorizontalAlignment_RightBarCheckItem1";
            this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandSelectPointerToolBarCheckItem1
            // 
            this.diagramCommandSelectPointerToolBarCheckItem1.Id = 151;
            this.diagramCommandSelectPointerToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectPointerToolBarCheckItem1.Name = "diagramCommandSelectPointerToolBarCheckItem1";
            this.diagramCommandSelectPointerToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandSelectConnectorToolBarCheckItem1
            // 
            this.diagramCommandSelectConnectorToolBarCheckItem1.Caption = "Transition";
            this.diagramCommandSelectConnectorToolBarCheckItem1.Id = 152;
            this.diagramCommandSelectConnectorToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectConnectorToolBarCheckItem1.Name = "diagramCommandSelectConnectorToolBarCheckItem1";
            this.diagramCommandSelectConnectorToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandToolsContainerCheckDropDownItem1
            // 
            this.diagramCommandToolsContainerCheckDropDownItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.CheckDropDown;
            this.diagramCommandToolsContainerCheckDropDownItem1.Caption = "Rectangle";
            this.diagramCommandToolsContainerCheckDropDownItem1.Description = "Drag to draw a rectangle.";
            this.diagramCommandToolsContainerCheckDropDownItem1.DropDownControl = this.ToolsContainerPopupMenu;
            this.diagramCommandToolsContainerCheckDropDownItem1.Id = 153;
            this.diagramCommandToolsContainerCheckDropDownItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText;
            this.diagramCommandToolsContainerCheckDropDownItem1.Name = "diagramCommandToolsContainerCheckDropDownItem1";
            this.diagramCommandToolsContainerCheckDropDownItem1.RememberLastCommand = true;
            this.diagramCommandToolsContainerCheckDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            toolTipTitleItem59.Text = "Rectangle (Ctrl+8)";
            toolTipItem1.Text = "Drag to draw a rectangle.";
            superToolTip59.Items.Add(toolTipTitleItem59);
            superToolTip59.Items.Add(toolTipItem1);
            this.diagramCommandToolsContainerCheckDropDownItem1.SuperTip = superToolTip59;
            // 
            // ToolsContainerPopupMenu
            // 
            this.ToolsContainerPopupMenu.ItemLinks.Add(this.diagramCommandSelectRectangleToolBarCheckItem1);
            this.ToolsContainerPopupMenu.ItemLinks.Add(this.diagramCommandSelectEllipseToolBarCheckItem1);
            this.ToolsContainerPopupMenu.ItemLinks.Add(this.diagramCommandSelectRightTriangleToolBarCheckItem1);
            this.ToolsContainerPopupMenu.ItemLinks.Add(this.diagramCommandSelectHexagonToolBarCheckItem1);
            this.ToolsContainerPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText;
            this.ToolsContainerPopupMenu.Name = "ToolsContainerPopupMenu";
            this.ToolsContainerPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandSelectRectangleToolBarCheckItem1
            // 
            this.diagramCommandSelectRectangleToolBarCheckItem1.Id = 155;
            this.diagramCommandSelectRectangleToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectRectangleToolBarCheckItem1.Name = "diagramCommandSelectRectangleToolBarCheckItem1";
            this.diagramCommandSelectRectangleToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandSelectEllipseToolBarCheckItem1
            // 
            this.diagramCommandSelectEllipseToolBarCheckItem1.Id = 156;
            this.diagramCommandSelectEllipseToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectEllipseToolBarCheckItem1.Name = "diagramCommandSelectEllipseToolBarCheckItem1";
            this.diagramCommandSelectEllipseToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandSelectRightTriangleToolBarCheckItem1
            // 
            this.diagramCommandSelectRightTriangleToolBarCheckItem1.Id = 157;
            this.diagramCommandSelectRightTriangleToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectRightTriangleToolBarCheckItem1.Name = "diagramCommandSelectRightTriangleToolBarCheckItem1";
            this.diagramCommandSelectRightTriangleToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandSelectHexagonToolBarCheckItem1
            // 
            this.diagramCommandSelectHexagonToolBarCheckItem1.Id = 158;
            this.diagramCommandSelectHexagonToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectHexagonToolBarCheckItem1.Name = "diagramCommandSelectHexagonToolBarCheckItem1";
            this.diagramCommandSelectHexagonToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandSelectPanToolBarCheckItem1
            // 
            this.diagramCommandSelectPanToolBarCheckItem1.Id = 154;
            this.diagramCommandSelectPanToolBarCheckItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectPanToolBarCheckItem1.Name = "diagramCommandSelectPanToolBarCheckItem1";
            this.diagramCommandSelectPanToolBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // diagramCommandShapeStylesBarGalleryItem1
            // 
            // 
            // 
            // 
            this.diagramCommandShapeStylesBarGalleryItem1.Gallery.ColumnCount = 7;
            galleryItemGroup4.Caption = "Variant Styles";
            galleryItemGroup4.Tag = "Variant Styles";
            galleryItemGroup5.Caption = "Theme Styles";
            galleryItemGroup5.Tag = "Theme Styles";
            this.diagramCommandShapeStylesBarGalleryItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup4,
            galleryItemGroup5});
            this.diagramCommandShapeStylesBarGalleryItem1.Gallery.ImageSize = new System.Drawing.Size(43, 43);
            this.diagramCommandShapeStylesBarGalleryItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.diagramCommandShapeStylesBarGalleryItem1.Gallery.RowCount = 7;
            this.diagramCommandShapeStylesBarGalleryItem1.Gallery.ScaleImages = DevExpress.Utils.DefaultBoolean.True;
            this.diagramCommandShapeStylesBarGalleryItem1.Id = 159;
            this.diagramCommandShapeStylesBarGalleryItem1.Name = "diagramCommandShapeStylesBarGalleryItem1";
            // 
            // diagramCommandBackgroundColorBarSplitButtonItem1
            // 
            this.diagramCommandBackgroundColorBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandBackgroundColorBarSplitButtonItem1.Color = System.Drawing.Color.Empty;
            this.diagramCommandBackgroundColorBarSplitButtonItem1.Id = 160;
            this.diagramCommandBackgroundColorBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandBackgroundColorBarSplitButtonItem1.Name = "diagramCommandBackgroundColorBarSplitButtonItem1";
            this.diagramCommandBackgroundColorBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandStrokeColorBarSplitButtonItem1
            // 
            this.diagramCommandStrokeColorBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandStrokeColorBarSplitButtonItem1.Color = System.Drawing.Color.Empty;
            this.diagramCommandStrokeColorBarSplitButtonItem1.Id = 161;
            this.diagramCommandStrokeColorBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandStrokeColorBarSplitButtonItem1.Name = "diagramCommandStrokeColorBarSplitButtonItem1";
            this.diagramCommandStrokeColorBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // diagramCommandBringToFrontBarSplitButtonItem1
            // 
            this.diagramCommandBringToFrontBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandBringToFrontBarSplitButtonItem1.DropDownControl = this.BringToFrontPopupMenu;
            this.diagramCommandBringToFrontBarSplitButtonItem1.Id = 162;
            this.diagramCommandBringToFrontBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandBringToFrontBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText;
            this.diagramCommandBringToFrontBarSplitButtonItem1.Name = "diagramCommandBringToFrontBarSplitButtonItem1";
            this.diagramCommandBringToFrontBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // BringToFrontPopupMenu
            // 
            this.BringToFrontPopupMenu.ItemLinks.Add(this.diagramCommandBringForwardBarButtonItem1);
            this.BringToFrontPopupMenu.ItemLinks.Add(this.diagramCommandBringToFrontBarButtonItem1);
            this.BringToFrontPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText;
            this.BringToFrontPopupMenu.Name = "BringToFrontPopupMenu";
            this.BringToFrontPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // diagramCommandSendToBackBarSplitButtonItem1
            // 
            this.diagramCommandSendToBackBarSplitButtonItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.diagramCommandSendToBackBarSplitButtonItem1.DropDownControl = this.SendToBackPopupMenu;
            this.diagramCommandSendToBackBarSplitButtonItem1.Id = 163;
            this.diagramCommandSendToBackBarSplitButtonItem1.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSendToBackBarSplitButtonItem1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText;
            this.diagramCommandSendToBackBarSplitButtonItem1.Name = "diagramCommandSendToBackBarSplitButtonItem1";
            this.diagramCommandSendToBackBarSplitButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // SendToBackPopupMenu
            // 
            this.SendToBackPopupMenu.ItemLinks.Add(this.diagramCommandSendBackwardBarButtonItem1);
            this.SendToBackPopupMenu.ItemLinks.Add(this.diagramCommandSendToBackBarButtonItem1);
            this.SendToBackPopupMenu.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.SmallImagesText;
            this.SendToBackPopupMenu.Name = "SendToBackPopupMenu";
            this.SendToBackPopupMenu.Ribbon = this.ribbonControl1;
            // 
            // ribbonGalleryBarItem1
            // 
            this.ribbonGalleryBarItem1.Caption = "ribbonGalleryBarItem1";
            // 
            // 
            // 
            galleryItemGroup6.Caption = "Group1";
            galleryItem1.Caption = "Item1";
            galleryItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            galleryItemGroup6.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            galleryItem1});
            this.ribbonGalleryBarItem1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup6});
            this.ribbonGalleryBarItem1.Id = 164;
            this.ribbonGalleryBarItem1.Name = "ribbonGalleryBarItem1";
            this.ribbonGalleryBarItem1.GalleryItemClick += new DevExpress.XtraBars.Ribbon.GalleryItemClickEventHandler(this.ribbonGalleryBarItem1_GalleryItemClick);
            // 
            // bbiState
            // 
            this.bbiState.Caption = "State";
            this.bbiState.Id = 168;
            this.bbiState.Name = "bbiState";
            this.bbiState.ItemPress += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiState_ItemPress);
            // 
            // bbiBranch
            // 
            this.bbiBranch.Caption = "Branch";
            this.bbiBranch.Id = 169;
            this.bbiBranch.Name = "bbiBranch";
            // 
            // bbiFinalState
            // 
            this.bbiFinalState.Caption = "Final State";
            this.bbiFinalState.Id = 170;
            this.bbiFinalState.Name = "bbiFinalState";
            // 
            // bbiCompositeInitialStatePointer
            // 
            this.bbiCompositeInitialStatePointer.Caption = "Initial State Pointer";
            this.bbiCompositeInitialStatePointer.Id = 171;
            this.bbiCompositeInitialStatePointer.Name = "bbiCompositeInitialStatePointer";
            // 
            // bbiCompositeState
            // 
            this.bbiCompositeState.Caption = "Composite State";
            this.bbiCompositeState.Id = 172;
            this.bbiCompositeState.Name = "bbiCompositeState";
            // 
            // bbiEntryPoint
            // 
            this.bbiEntryPoint.Caption = "Entry Point";
            this.bbiEntryPoint.Id = 173;
            this.bbiEntryPoint.Name = "bbiEntryPoint";
            // 
            // bbiHistoryState
            // 
            this.bbiHistoryState.Caption = "History State";
            this.bbiHistoryState.Id = 174;
            this.bbiHistoryState.Name = "bbiHistoryState";
            // 
            // diagramContainerToolsRibbonPageCategory1
            // 
            this.diagramContainerToolsRibbonPageCategory1.AutoStretchPageHeaders = true;
            this.diagramContainerToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(157)))), ((int)(((byte)(0)))));
            this.diagramContainerToolsRibbonPageCategory1.Control = this.diagramControl1;
            this.diagramContainerToolsRibbonPageCategory1.Name = "diagramContainerToolsRibbonPageCategory1";
            this.diagramContainerToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.diagramFormatContainerRibbonPage1});
            // 
            // diagramFormatContainerRibbonPage1
            // 
            this.diagramFormatContainerRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.diagramContainerSizeRibbonPageGroup1,
            this.diagramContainerStylesRibbonPageGroup1});
            this.diagramFormatContainerRibbonPage1.Name = "diagramFormatContainerRibbonPage1";
            // 
            // diagramContainerSizeRibbonPageGroup1
            // 
            this.diagramContainerSizeRibbonPageGroup1.AllowTextClipping = false;
            this.diagramContainerSizeRibbonPageGroup1.ItemLinks.Add(this.diagramCommandContainerPaddingBarDropDownItem1);
            this.diagramContainerSizeRibbonPageGroup1.ItemLinks.Add(this.diagramCommandContainerHeaderPaddingBarDropDownItem1);
            this.diagramContainerSizeRibbonPageGroup1.Name = "diagramContainerSizeRibbonPageGroup1";
            // 
            // diagramContainerStylesRibbonPageGroup1
            // 
            this.diagramContainerStylesRibbonPageGroup1.AllowTextClipping = false;
            this.diagramContainerStylesRibbonPageGroup1.ItemLinks.Add(this.diagramCommandContainerStylesBarGalleryItem1);
            this.diagramContainerStylesRibbonPageGroup1.ItemLinks.Add(this.diagramCommandShowContainerHeaderBarCheckItem1);
            this.diagramContainerStylesRibbonPageGroup1.Name = "diagramContainerStylesRibbonPageGroup1";
            // 
            // diagramImageToolsRibbonPageCategory1
            // 
            this.diagramImageToolsRibbonPageCategory1.AutoStretchPageHeaders = true;
            this.diagramImageToolsRibbonPageCategory1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(163)))), ((int)(((byte)(73)))));
            this.diagramImageToolsRibbonPageCategory1.Control = this.diagramControl1;
            this.diagramImageToolsRibbonPageCategory1.Name = "diagramImageToolsRibbonPageCategory1";
            this.diagramImageToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.diagramFormatImageRibbonPage1});
            // 
            // diagramFormatImageRibbonPage1
            // 
            this.diagramFormatImageRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.diagramImageTools_ArrangeRibbonPageGroup1,
            this.diagramImageTools_PictureRibbonPageGroup1});
            this.diagramFormatImageRibbonPage1.Name = "diagramFormatImageRibbonPage1";
            // 
            // diagramImageTools_ArrangeRibbonPageGroup1
            // 
            this.diagramImageTools_ArrangeRibbonPageGroup1.AllowTextClipping = false;
            this.diagramImageTools_ArrangeRibbonPageGroup1.ItemLinks.Add(this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1);
            this.diagramImageTools_ArrangeRibbonPageGroup1.ItemLinks.Add(this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1);
            this.diagramImageTools_ArrangeRibbonPageGroup1.Name = "diagramImageTools_ArrangeRibbonPageGroup1";
            // 
            // diagramImageTools_PictureRibbonPageGroup1
            // 
            this.diagramImageTools_PictureRibbonPageGroup1.AllowTextClipping = false;
            this.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(this.diagramCommandImageToolsRotateBarDropDownItem1);
            this.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(this.diagramCommandImageToolsStretchModeBarDropDownItem1);
            this.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(this.diagramCommandImageToolsSetImageScaleBarDropDownItem1);
            this.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(this.diagramCommandResetSelectedImagesBarButtonItem1);
            this.diagramImageTools_PictureRibbonPageGroup1.ItemLinks.Add(this.diagramCommandLoadImageBarButtonItem1);
            this.diagramImageTools_PictureRibbonPageGroup1.Name = "diagramImageTools_PictureRibbonPageGroup1";
            // 
            // diagramHomeRibbonPage1
            // 
            this.diagramHomeRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.diagramClipboardRibbonPageGroup1,
            this.diagramFontRibbonPageGroup1,
            this.diagramParagraphRibbonPageGroup1,
            this.diagramToolsRibbonPageGroup1,
            this.ribbonPageGroup2,
            this.ribbonPageGroup1,
            this.diagramShapeStylesRibbonPageGroup1,
            this.diagramArrangeRibbonPageGroup1});
            this.diagramHomeRibbonPage1.Name = "diagramHomeRibbonPage1";
            // 
            // diagramClipboardRibbonPageGroup1
            // 
            this.diagramClipboardRibbonPageGroup1.AllowTextClipping = false;
            this.diagramClipboardRibbonPageGroup1.ItemLinks.Add(this.diagramCommandPasteBarButtonItem1);
            this.diagramClipboardRibbonPageGroup1.ItemLinks.Add(this.diagramCommandCutBarButtonItem1);
            this.diagramClipboardRibbonPageGroup1.ItemLinks.Add(this.diagramCommandCopyBarButtonItem1);
            this.diagramClipboardRibbonPageGroup1.Name = "diagramClipboardRibbonPageGroup1";
            // 
            // diagramFontRibbonPageGroup1
            // 
            this.diagramFontRibbonPageGroup1.AllowTextClipping = false;
            this.diagramFontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup1);
            this.diagramFontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup2);
            this.diagramFontRibbonPageGroup1.Name = "diagramFontRibbonPageGroup1";
            // 
            // diagramParagraphRibbonPageGroup1
            // 
            this.diagramParagraphRibbonPageGroup1.AllowTextClipping = false;
            this.diagramParagraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup3);
            this.diagramParagraphRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup4);
            this.diagramParagraphRibbonPageGroup1.Name = "diagramParagraphRibbonPageGroup1";
            // 
            // diagramToolsRibbonPageGroup1
            // 
            this.diagramToolsRibbonPageGroup1.AllowTextClipping = false;
            this.diagramToolsRibbonPageGroup1.ItemLinks.Add(this.diagramCommandToolsContainerCheckDropDownItem1);
            this.diagramToolsRibbonPageGroup1.Name = "diagramToolsRibbonPageGroup1";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.diagramCommandSelectPointerToolBarCheckItem1, true);
            this.ribbonPageGroup2.ItemLinks.Add(this.diagramCommandSelectConnectorToolBarCheckItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.diagramCommandSelectPanToolBarCheckItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiState);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiEntryPoint);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiFinalState);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiBranch);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiCompositeState);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiCompositeInitialStatePointer);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiHistoryState);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "ribbonPageGroup2";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.ribbonGalleryBarItem1);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // diagramShapeStylesRibbonPageGroup1
            // 
            this.diagramShapeStylesRibbonPageGroup1.AllowTextClipping = false;
            this.diagramShapeStylesRibbonPageGroup1.ItemLinks.Add(this.diagramCommandShapeStylesBarGalleryItem1);
            this.diagramShapeStylesRibbonPageGroup1.ItemLinks.Add(this.diagramCommandBackgroundColorBarSplitButtonItem1);
            this.diagramShapeStylesRibbonPageGroup1.ItemLinks.Add(this.diagramCommandStrokeColorBarSplitButtonItem1);
            this.diagramShapeStylesRibbonPageGroup1.Name = "diagramShapeStylesRibbonPageGroup1";
            // 
            // diagramArrangeRibbonPageGroup1
            // 
            this.diagramArrangeRibbonPageGroup1.AllowTextClipping = false;
            this.diagramArrangeRibbonPageGroup1.ItemLinks.Add(this.diagramCommandBringToFrontBarSplitButtonItem1);
            this.diagramArrangeRibbonPageGroup1.ItemLinks.Add(this.diagramCommandSendToBackBarSplitButtonItem1);
            this.diagramArrangeRibbonPageGroup1.Name = "diagramArrangeRibbonPageGroup1";
            // 
            // diagramInsertRibbonPage1
            // 
            this.diagramInsertRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.diagramDiagramPartsRibbonPageGroup1});
            this.diagramInsertRibbonPage1.Name = "diagramInsertRibbonPage1";
            // 
            // diagramDiagramPartsRibbonPageGroup1
            // 
            this.diagramDiagramPartsRibbonPageGroup1.AllowTextClipping = false;
            this.diagramDiagramPartsRibbonPageGroup1.ItemLinks.Add(this.diagramCommandInsertContainerBarSplitButtonItem1);
            this.diagramDiagramPartsRibbonPageGroup1.ItemLinks.Add(this.diagramCommandInsertImageBarButtonItem1);
            this.diagramDiagramPartsRibbonPageGroup1.Name = "diagramDiagramPartsRibbonPageGroup1";
            // 
            // diagramDesignRibbonPage1
            // 
            this.diagramDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.diagramPageSetupRibbonPageGroup1,
            this.diagramThemesRibbonPageGroup1,
            this.diagramOptionsRibbonPageGroup1,
            this.diagramTreeLayoutRibbonPageGroup1});
            this.diagramDesignRibbonPage1.Name = "diagramDesignRibbonPage1";
            // 
            // diagramPageSetupRibbonPageGroup1
            // 
            this.diagramPageSetupRibbonPageGroup1.AllowTextClipping = false;
            this.diagramPageSetupRibbonPageGroup1.ItemLinks.Add(this.diagramCommandPageOrientationBarDropDownItem1);
            this.diagramPageSetupRibbonPageGroup1.ItemLinks.Add(this.diagramCommandPageSizeBarDropDownItem1);
            this.diagramPageSetupRibbonPageGroup1.ItemLinks.Add(this.diagramCommandAutoSizeBarDropDownItem1);
            this.diagramPageSetupRibbonPageGroup1.Name = "diagramPageSetupRibbonPageGroup1";
            // 
            // diagramThemesRibbonPageGroup1
            // 
            this.diagramThemesRibbonPageGroup1.AllowTextClipping = false;
            this.diagramThemesRibbonPageGroup1.ItemLinks.Add(this.diagramCommandThemesBarGalleryItem1);
            this.diagramThemesRibbonPageGroup1.Name = "diagramThemesRibbonPageGroup1";
            // 
            // diagramOptionsRibbonPageGroup1
            // 
            this.diagramOptionsRibbonPageGroup1.AllowTextClipping = false;
            this.diagramOptionsRibbonPageGroup1.ItemLinks.Add(this.diagramCommandSnapToItemsBarCheckItem1);
            this.diagramOptionsRibbonPageGroup1.ItemLinks.Add(this.diagramCommandSnapToGridBarCheckItem1);
            this.diagramOptionsRibbonPageGroup1.Name = "diagramOptionsRibbonPageGroup1";
            // 
            // diagramTreeLayoutRibbonPageGroup1
            // 
            this.diagramTreeLayoutRibbonPageGroup1.AllowTextClipping = false;
            this.diagramTreeLayoutRibbonPageGroup1.ItemLinks.Add(this.diagramCommandReLayoutBarDropDownItem1);
            this.diagramTreeLayoutRibbonPageGroup1.ItemLinks.Add(this.diagramCommandChangeConnectorTypeBarDropDownItem1);
            this.diagramTreeLayoutRibbonPageGroup1.ItemLinks.Add(this.diagramCommandReLayoutPartsBarDropDownItem1);
            this.diagramTreeLayoutRibbonPageGroup1.Name = "diagramTreeLayoutRibbonPageGroup1";
            // 
            // diagramViewRibbonPage1
            // 
            this.diagramViewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.diagramShowRibbonPageGroup1,
            this.diagramZoomRibbonPageGroup1});
            this.diagramViewRibbonPage1.Name = "diagramViewRibbonPage1";
            // 
            // diagramShowRibbonPageGroup1
            // 
            this.diagramShowRibbonPageGroup1.AllowTextClipping = false;
            this.diagramShowRibbonPageGroup1.ItemLinks.Add(this.diagramCommandShowRulersBarCheckItem1);
            this.diagramShowRibbonPageGroup1.ItemLinks.Add(this.diagramCommandShowGridBarCheckItem1);
            this.diagramShowRibbonPageGroup1.ItemLinks.Add(this.diagramCommandShowPageBreaksBarCheckItem1);
            this.diagramShowRibbonPageGroup1.ItemLinks.Add(this.diagramCommandPanesBarDropDownItem1);
            this.diagramShowRibbonPageGroup1.Name = "diagramShowRibbonPageGroup1";
            // 
            // diagramZoomRibbonPageGroup1
            // 
            this.diagramZoomRibbonPageGroup1.AllowTextClipping = false;
            this.diagramZoomRibbonPageGroup1.ItemLinks.Add(this.diagramCommandFitToPageBarButtonItem1);
            this.diagramZoomRibbonPageGroup1.ItemLinks.Add(this.diagramCommandFitToWidthBarButtonItem1);
            this.diagramZoomRibbonPageGroup1.Name = "diagramZoomRibbonPageGroup1";
            // 
            // ribbonStatusBar1
            // 
            this.ribbonStatusBar1.ItemLinks.Add(this.diagramStatusBarShapeInfoBarStaticItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.diagramCommandStatusBarZoomEditorBarEditItem1);
            this.ribbonStatusBar1.Location = new System.Drawing.Point(0, 684);
            this.ribbonStatusBar1.Name = "ribbonStatusBar1";
            this.ribbonStatusBar1.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar1.Size = new System.Drawing.Size(2301, 27);
            // 
            // diagramBarController1
            // 
            this.diagramBarController1.BarItems.Add(this.diagramCommandNewFileBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandOpenFileBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSaveFileBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSaveFileAsBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShowPrintPreviewBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPrintMenuBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandExportAsBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandUndoBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandRedoBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPrintBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandQuickPrintBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandExportDiagram_PNGBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandExportDiagram_JPEGBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandExportDiagram_BMPBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandExportDiagram_GIFBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramStatusBarShapeInfoBarStaticItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandStatusBarZoomEditorBarEditItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPaddingBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPaddingBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P0BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P4BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P8BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P12BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P16BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P24BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerPadding_P32BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P0BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P4BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P8BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P12BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P16BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P24BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerHeaderPadding_P32BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandContainerStylesBarGalleryItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShowContainerHeaderBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandBringForwardBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandBringToFrontBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSendBackwardBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSendToBackBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsRotateBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsStretchModeBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScaleBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandResetSelectedImagesBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandLoadImageBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandRotate_Right90BarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandRotate_Left90BarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFlipImage_VerticalBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFlipImage_HorizontalBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_0_25BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_0_5BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_0_75BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_1BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_1_5BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_2BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandImageToolsSetImageScale_4BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShowRulersBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShowGridBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShowPageBreaksBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPanesBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShapesPanelBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPropertiesPanelBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFitToPageBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFitToWidthBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageOrientationBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSizeBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandAutoSizeBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageOrientation_HorizontalBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageOrientation_VerticalBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_LetterBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_TabloidBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_LegalBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_StatementBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_ExecutiveBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_A3BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_A4BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_A5BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_B4BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPageSize_B5BarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFitToDrawingBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetPageParameters_PageSizeBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandAutoSize_NoneBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandAutoSize_AutoSizeBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandAutoSize_FillBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandThemesBarGalleryItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSnapToItemsBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSnapToGridBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandReLayoutBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandChangeConnectorTypeBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandReLayoutPartsBarDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutTreeBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayout_DownBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayout_UpBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayout_RightBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayout_LeftBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutTipOverTreeHeaderBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutMindMapTreeHeaderBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandMindMapTreeLayout_VerticalBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutSugiyamaBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSugiyamaLayout_DownBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSugiyamaLayout_UpBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSugiyamaLayout_RightBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSugiyamaLayout_LeftBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutCircularHeaderBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandCircularLayoutBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandChangeConnectorType_RightAngleBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandChangeConnectorType_CurvedBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandChangeConnectorType_StraightBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutPartsTreeHeaderBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandInsertContainerBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandInsertImageBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandPasteBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandCutBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandCopyBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFontFamilyBarEditItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandFontSizeBarEditItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandIncreaseFontSizeBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandDecreaseFontSizeBarButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandToggleFontBoldBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandToggleFontItalicBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandToggleFontUnderlineBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandToggleFontStrikethroughBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandForegroundColorBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetVerticalAlignment_TopBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetVerticalAlignment_CenterBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetVerticalAlignment_BottomBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetHorizontalAlignment_LeftBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetHorizontalAlignment_CenterBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSetHorizontalAlignment_RightBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectPointerToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectConnectorToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandToolsContainerCheckDropDownItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectPanToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectRectangleToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectEllipseToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectRightTriangleToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSelectHexagonToolBarCheckItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandShapeStylesBarGalleryItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandBackgroundColorBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandStrokeColorBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandBringToFrontBarSplitButtonItem1);
            this.diagramBarController1.BarItems.Add(this.diagramCommandSendToBackBarSplitButtonItem1);
            this.diagramBarController1.Control = this.diagramControl1;
            // 
            // diagramCommandSelectConnectorToolBarCheckItem2
            // 
            this.diagramCommandSelectConnectorToolBarCheckItem2.Id = 152;
            this.diagramCommandSelectConnectorToolBarCheckItem2.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.False;
            this.diagramCommandSelectConnectorToolBarCheckItem2.Name = "diagramCommandSelectConnectorToolBarCheckItem2";
            this.diagramCommandSelectConnectorToolBarCheckItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2301, 711);
            this.Controls.Add(this.diagramControl1);
            this.Controls.Add(this.ribbonStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.diagramControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintMenuPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExportAsPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diagramRepositoryItemZoomTrackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageToolsBringToFrontContainerPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageToolsSendToBackContainerPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InsertContainerPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDiagramFontSizeEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToolsContainerPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BringToFrontPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SendToBackPopupMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diagramBarController1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraDiagram.DiagramControl diagramControl1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.ApplicationMenu applicationMenu1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandNewFileBarButtonItem diagramCommandNewFileBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandOpenFileBarButtonItem diagramCommandOpenFileBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileBarButtonItem diagramCommandSaveFileBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSaveFileAsBarButtonItem diagramCommandSaveFileAsBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShowPrintPreviewBarButtonItem diagramCommandShowPrintPreviewBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPrintMenuBarSplitButtonItem diagramCommandPrintMenuBarSplitButtonItem1;
        private DevExpress.XtraBars.PopupMenu PrintMenuPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPrintBarButtonItem diagramCommandPrintBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandQuickPrintBarButtonItem diagramCommandQuickPrintBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandExportAsBarSplitButtonItem diagramCommandExportAsBarSplitButtonItem1;
        private DevExpress.XtraBars.PopupMenu ExportAsPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_PNGBarButtonItem diagramCommandExportDiagram_PNGBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_JPEGBarButtonItem diagramCommandExportDiagram_JPEGBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_BMPBarButtonItem diagramCommandExportDiagram_BMPBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandExportDiagram_GIFBarButtonItem diagramCommandExportDiagram_GIFBarButtonItem1;
        private DevExpress.XtraBars.BarAndDockingController barAndDockingController1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandUndoBarButtonItem diagramCommandUndoBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandRedoBarButtonItem diagramCommandRedoBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramStatusBarShapeInfoBarStaticItem diagramStatusBarShapeInfoBarStaticItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem diagramCommandStatusBarZoomEditorBarEditItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandStatusBarZoomEditorBarEditItem.DiagramRepositoryItemZoomTrackBar diagramRepositoryItemZoomTrackBar1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPaddingBarDropDownItem diagramCommandContainerPaddingBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P0BarCheckItem diagramCommandContainerPadding_P0BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P4BarCheckItem diagramCommandContainerPadding_P4BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P8BarCheckItem diagramCommandContainerPadding_P8BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P12BarCheckItem diagramCommandContainerPadding_P12BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P16BarCheckItem diagramCommandContainerPadding_P16BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P24BarCheckItem diagramCommandContainerPadding_P24BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerPadding_P32BarCheckItem diagramCommandContainerPadding_P32BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPaddingBarDropDownItem diagramCommandContainerHeaderPaddingBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P0BarCheckItem diagramCommandContainerHeaderPadding_P0BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P4BarCheckItem diagramCommandContainerHeaderPadding_P4BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P8BarCheckItem diagramCommandContainerHeaderPadding_P8BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P12BarCheckItem diagramCommandContainerHeaderPadding_P12BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P16BarCheckItem diagramCommandContainerHeaderPadding_P16BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P24BarCheckItem diagramCommandContainerHeaderPadding_P24BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerHeaderPadding_P32BarCheckItem diagramCommandContainerHeaderPadding_P32BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandContainerStylesBarGalleryItem diagramCommandContainerStylesBarGalleryItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShowContainerHeaderBarCheckItem diagramCommandShowContainerHeaderBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsBringToFrontContainerBarSplitButtonItem diagramCommandImageToolsBringToFrontContainerBarSplitButtonItem1;
        private DevExpress.XtraBars.PopupMenu ImageToolsBringToFrontContainerPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandBringForwardBarButtonItem diagramCommandBringForwardBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarButtonItem diagramCommandBringToFrontBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSendToBackContainerBarSplitButtonItem diagramCommandImageToolsSendToBackContainerBarSplitButtonItem1;
        private DevExpress.XtraBars.PopupMenu ImageToolsSendToBackContainerPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSendBackwardBarButtonItem diagramCommandSendBackwardBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarButtonItem diagramCommandSendToBackBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsRotateBarDropDownItem diagramCommandImageToolsRotateBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Right90BarButtonItem diagramCommandRotate_Right90BarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandRotate_Left90BarButtonItem diagramCommandRotate_Left90BarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_VerticalBarButtonItem diagramCommandFlipImage_VerticalBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFlipImage_HorizontalBarButtonItem diagramCommandFlipImage_HorizontalBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsStretchModeBarDropDownItem diagramCommandImageToolsStretchModeBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem diagramCommandSetSelectedImagesStretchMode_StretchBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem diagramCommandSetSelectedImagesStretchMode_UniformBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem diagramCommandSetSelectedImagesStretchMode_UniformToFillBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScaleBarDropDownItem diagramCommandImageToolsSetImageScaleBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_25BarCheckItem diagramCommandImageToolsSetImageScale_0_25BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_5BarCheckItem diagramCommandImageToolsSetImageScale_0_5BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_0_75BarCheckItem diagramCommandImageToolsSetImageScale_0_75BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1BarCheckItem diagramCommandImageToolsSetImageScale_1BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_1_5BarCheckItem diagramCommandImageToolsSetImageScale_1_5BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_2BarCheckItem diagramCommandImageToolsSetImageScale_2BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandImageToolsSetImageScale_4BarCheckItem diagramCommandImageToolsSetImageScale_4BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandResetSelectedImagesBarButtonItem diagramCommandResetSelectedImagesBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandLoadImageBarButtonItem diagramCommandLoadImageBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShowRulersBarCheckItem diagramCommandShowRulersBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShowGridBarCheckItem diagramCommandShowGridBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShowPageBreaksBarCheckItem diagramCommandShowPageBreaksBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPanesBarDropDownItem diagramCommandPanesBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShapesPanelBarCheckItem diagramCommandShapesPanelBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPropertiesPanelBarCheckItem diagramCommandPropertiesPanelBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFitToPageBarButtonItem diagramCommandFitToPageBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFitToWidthBarButtonItem diagramCommandFitToWidthBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientationBarDropDownItem diagramCommandPageOrientationBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_HorizontalBarCheckItem diagramCommandPageOrientation_HorizontalBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageOrientation_VerticalBarCheckItem diagramCommandPageOrientation_VerticalBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSizeBarDropDownItem diagramCommandPageSizeBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LetterBarCheckItem diagramCommandPageSize_LetterBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_TabloidBarCheckItem diagramCommandPageSize_TabloidBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_LegalBarCheckItem diagramCommandPageSize_LegalBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_StatementBarCheckItem diagramCommandPageSize_StatementBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_ExecutiveBarCheckItem diagramCommandPageSize_ExecutiveBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A3BarCheckItem diagramCommandPageSize_A3BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A4BarCheckItem diagramCommandPageSize_A4BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_A5BarCheckItem diagramCommandPageSize_A5BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B4BarCheckItem diagramCommandPageSize_B4BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPageSize_B5BarCheckItem diagramCommandPageSize_B5BarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFitToDrawingBarButtonItem diagramCommandFitToDrawingBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetPageParameters_PageSizeBarButtonItem diagramCommandSetPageParameters_PageSizeBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandAutoSizeBarDropDownItem diagramCommandAutoSizeBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_NoneBarCheckItem diagramCommandAutoSize_NoneBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_AutoSizeBarCheckItem diagramCommandAutoSize_AutoSizeBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandAutoSize_FillBarCheckItem diagramCommandAutoSize_FillBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandThemesBarGalleryItem diagramCommandThemesBarGalleryItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSnapToItemsBarCheckItem diagramCommandSnapToItemsBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSnapToGridBarCheckItem diagramCommandSnapToGridBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandReLayoutBarDropDownItem diagramCommandReLayoutBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutTreeBarHeaderItem diagramReLayoutTreeBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_DownBarButtonItem diagramCommandTreeLayout_DownBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_UpBarButtonItem diagramCommandTreeLayout_UpBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_RightBarButtonItem diagramCommandTreeLayout_RightBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayout_LeftBarButtonItem diagramCommandTreeLayout_LeftBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutTipOverTreeHeaderBarHeaderItem diagramReLayoutTipOverTreeHeaderBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_LeftToRightBarButtonItem diagramCommandTipOverTreeLayout_LeftToRightBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayout_RightToLeftBarButtonItem diagramCommandTipOverTreeLayout_RightToLeftBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutMindMapTreeHeaderBarHeaderItem diagramReLayoutMindMapTreeHeaderBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayout_HorizontalBarButtonItem diagramCommandMindMapTreeLayout_HorizontalBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayout_VerticalBarButtonItem diagramCommandMindMapTreeLayout_VerticalBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutSugiyamaBarHeaderItem diagramReLayoutSugiyamaBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_DownBarButtonItem diagramCommandSugiyamaLayout_DownBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_UpBarButtonItem diagramCommandSugiyamaLayout_UpBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_RightBarButtonItem diagramCommandSugiyamaLayout_RightBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSugiyamaLayout_LeftBarButtonItem diagramCommandSugiyamaLayout_LeftBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutCircularHeaderBarHeaderItem diagramReLayoutCircularHeaderBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandCircularLayoutBarButtonItem diagramCommandCircularLayoutBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorTypeBarDropDownItem diagramCommandChangeConnectorTypeBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorType_RightAngleBarButtonItem diagramCommandChangeConnectorType_RightAngleBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorType_CurvedBarButtonItem diagramCommandChangeConnectorType_CurvedBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandChangeConnectorType_StraightBarButtonItem diagramCommandChangeConnectorType_StraightBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandReLayoutPartsBarDropDownItem diagramCommandReLayoutPartsBarDropDownItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutPartsTreeHeaderBarHeaderItem diagramReLayoutPartsTreeHeaderBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem diagramCommandTreeLayoutForSubordinates_TopToBottomBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem diagramCommandTreeLayoutForSubordinates_BottomToTopBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem diagramCommandTreeLayoutForSubordinates_LeftToRightBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem diagramCommandTreeLayoutForSubordinates_RightToLeftBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutPartsTipOverTreeHeaderBarHeaderItem diagramReLayoutPartsTipOverTreeHeaderBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem diagramCommandTipOverTreeLayoutForSubordinates_LeftToRightBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem diagramCommandTipOverTreeLayoutForSubordinates_RightToLeftBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramReLayoutPartsMindMapTreeHeaderBarHeaderItem diagramReLayoutPartsMindMapTreeHeaderBarHeaderItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem diagramCommandMindMapTreeLayoutForSubordinates_HorizontalBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem diagramCommandMindMapTreeLayoutForSubordinates_VerticalBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandInsertContainerBarSplitButtonItem diagramCommandInsertContainerBarSplitButtonItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown InsertContainerPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandInsertImageBarButtonItem diagramCommandInsertImageBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandPasteBarButtonItem diagramCommandPasteBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandCutBarButtonItem diagramCommandCutBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandCopyBarButtonItem diagramCommandCopyBarButtonItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFontFamilyBarEditItem diagramCommandFontFamilyBarEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemFontEdit repositoryItemFontEdit1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandFontSizeBarEditItem diagramCommandFontSizeBarEditItem1;
        private DevExpress.XtraDiagram.Bars.RepositoryItemDiagramFontSizeEdit repositoryItemDiagramFontSizeEdit1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandIncreaseFontSizeBarButtonItem diagramCommandIncreaseFontSizeBarButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandDecreaseFontSizeBarButtonItem diagramCommandDecreaseFontSizeBarButtonItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontBoldBarCheckItem diagramCommandToggleFontBoldBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontItalicBarCheckItem diagramCommandToggleFontItalicBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontUnderlineBarCheckItem diagramCommandToggleFontUnderlineBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandToggleFontStrikethroughBarCheckItem diagramCommandToggleFontStrikethroughBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandForegroundColorBarSplitButtonItem diagramCommandForegroundColorBarSplitButtonItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_TopBarCheckItem diagramCommandSetVerticalAlignment_TopBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_CenterBarCheckItem diagramCommandSetVerticalAlignment_CenterBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetVerticalAlignment_BottomBarCheckItem diagramCommandSetVerticalAlignment_BottomBarCheckItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_LeftBarCheckItem diagramCommandSetHorizontalAlignment_LeftBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_CenterBarCheckItem diagramCommandSetHorizontalAlignment_CenterBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSetHorizontalAlignment_RightBarCheckItem diagramCommandSetHorizontalAlignment_RightBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectPointerToolBarCheckItem diagramCommandSelectPointerToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectConnectorToolBarCheckItem diagramCommandSelectConnectorToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandToolsContainerCheckDropDownItem diagramCommandToolsContainerCheckDropDownItem1;
        private DevExpress.XtraBars.PopupMenu ToolsContainerPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectRectangleToolBarCheckItem diagramCommandSelectRectangleToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectEllipseToolBarCheckItem diagramCommandSelectEllipseToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectRightTriangleToolBarCheckItem diagramCommandSelectRightTriangleToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectHexagonToolBarCheckItem diagramCommandSelectHexagonToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectPanToolBarCheckItem diagramCommandSelectPanToolBarCheckItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandShapeStylesBarGalleryItem diagramCommandShapeStylesBarGalleryItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandBackgroundColorBarSplitButtonItem diagramCommandBackgroundColorBarSplitButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandStrokeColorBarSplitButtonItem diagramCommandStrokeColorBarSplitButtonItem1;
        private DevExpress.XtraDiagram.Bars.DiagramCommandBringToFrontBarSplitButtonItem diagramCommandBringToFrontBarSplitButtonItem1;
        private DevExpress.XtraBars.PopupMenu BringToFrontPopupMenu;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSendToBackBarSplitButtonItem diagramCommandSendToBackBarSplitButtonItem1;
        private DevExpress.XtraBars.PopupMenu SendToBackPopupMenu;
        private DevExpress.XtraBars.RibbonGalleryBarItem ribbonGalleryBarItem1;
        private DevExpress.XtraDiagram.Bars.DiagramContainerToolsRibbonPageCategory diagramContainerToolsRibbonPageCategory1;
        private DevExpress.XtraDiagram.Bars.DiagramFormatContainerRibbonPage diagramFormatContainerRibbonPage1;
        private DevExpress.XtraDiagram.Bars.DiagramContainerSizeRibbonPageGroup diagramContainerSizeRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramContainerStylesRibbonPageGroup diagramContainerStylesRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramImageToolsRibbonPageCategory diagramImageToolsRibbonPageCategory1;
        private DevExpress.XtraDiagram.Bars.DiagramFormatImageRibbonPage diagramFormatImageRibbonPage1;
        private DevExpress.XtraDiagram.Bars.DiagramImageTools_ArrangeRibbonPageGroup diagramImageTools_ArrangeRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramImageTools_PictureRibbonPageGroup diagramImageTools_PictureRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramHomeRibbonPage diagramHomeRibbonPage1;
        private DevExpress.XtraDiagram.Bars.DiagramClipboardRibbonPageGroup diagramClipboardRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramFontRibbonPageGroup diagramFontRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramParagraphRibbonPageGroup diagramParagraphRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramToolsRibbonPageGroup diagramToolsRibbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramShapeStylesRibbonPageGroup diagramShapeStylesRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramArrangeRibbonPageGroup diagramArrangeRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramInsertRibbonPage diagramInsertRibbonPage1;
        private DevExpress.XtraDiagram.Bars.DiagramDiagramPartsRibbonPageGroup diagramDiagramPartsRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramDesignRibbonPage diagramDesignRibbonPage1;
        private DevExpress.XtraDiagram.Bars.DiagramPageSetupRibbonPageGroup diagramPageSetupRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramThemesRibbonPageGroup diagramThemesRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramOptionsRibbonPageGroup diagramOptionsRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramTreeLayoutRibbonPageGroup diagramTreeLayoutRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramViewRibbonPage diagramViewRibbonPage1;
        private DevExpress.XtraDiagram.Bars.DiagramShowRibbonPageGroup diagramShowRibbonPageGroup1;
        private DevExpress.XtraDiagram.Bars.DiagramZoomRibbonPageGroup diagramZoomRibbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar1;
        private DevExpress.XtraDiagram.Bars.DiagramBarController diagramBarController1;
        private DevExpress.XtraBars.BarButtonItem bbiState;
        private DevExpress.XtraBars.BarButtonItem bbiBranch;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraDiagram.Bars.DiagramCommandSelectConnectorToolBarCheckItem diagramCommandSelectConnectorToolBarCheckItem2;
        private DevExpress.XtraBars.BarButtonItem bbiFinalState;
        private DevExpress.XtraBars.BarButtonItem bbiCompositeInitialStatePointer;
        private DevExpress.XtraBars.BarButtonItem bbiCompositeState;
        private DevExpress.XtraBars.BarButtonItem bbiEntryPoint;
        private DevExpress.XtraBars.BarButtonItem bbiHistoryState;
    }
}

